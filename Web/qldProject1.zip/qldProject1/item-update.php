<?php
session_start();

// Check if user is logged in, redirect to login page if not
if (!isset($_SESSION["id"])) {
    header("Location: login.php");
    exit;
}
$page = 'item-update.php'; 
$screen_name = 'Update Item';


$userid = $_SESSION["id"];
$userrole= $_SESSION["role_id"];

$item_mngt_id = isset($_GET['item_mngt_id']) ? $_GET['item_mngt_id'] : '';

include 'db/db_connection.php'; // Include your database connection

?>

<!DOCTYPE html>
<html>
<head>
    <!-- Head -->
    <?php include 'includecode/head.php' ?>
    <!-- Head -->
</head>
<style>
   <?php include 'includecode/plusdesign.php' ?>
</style>

    
<body id="page-top">
    <?php
        // Check if 'error' parameter is set in the URL
        if (isset($_GET['error'])) {
            // Display an error message with the value of the 'error' parameter
            echo '<div id="alert-containers" class="alert alert-danger" role="alert">' . $_GET['error'] . '</div>';
            
        }

        // Check if 'error' parameter is set in the URL
        if (isset($_GET['success'])) {
            // Display an error message with the value of the 'error' parameter
            echo '<div id="alert-containers" class="alert alert-success" role="success">' . $_GET['success'] . '</div>';
            
        }
    
    ?>

    <script>
        // Wait for the DOM to be ready
        document.addEventListener("DOMContentLoaded", function() {
            // Set a timeout to hide the error message after 5 seconds
            setTimeout(function() {
                var alertContainer = document.getElementById('alert-containers');
                if (alertContainer) {
                    // Hide the error message by setting display to 'none'
                    alertContainer.style.display = 'none';
                }
            }, 3000); // 3000 milliseconds = 3 seconds
        });
    </script>
    <!-- The modal -->
    <div id="imageModal" class="modala" onclick="closeModal()">
        <span class="closea" onclick="closeModal()">&times;</span>
        <img class="modala-content" id="largeImage">
    </div>

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Side Nav -->
        <?php include 'function/navigation/sidenav.php' ?>
        <!-- Side Nav -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include 'function/navigation/topnav.php' ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">Item's Details</h1>
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Update Item</h6>
                        </div>
                        <?php
                           
                                $sql = "SELECT 
                                            im.item_mngt_id,
                                            im.pic_id,
                                            im.item_id,
                                            im.item_mngt_status_id,
                                            ims.status_name AS item_management_status,                                                
                                            im.register_date,
                                            im.arrived_date,
                                            im.pickup_date,
                                            im.qrcode_recipient_id,
                                            qr1.recipient_id AS recipient_id,
                                            im.qrcode_delivery_id,
                                            qr2.courier_id AS courier_id,
                                            qr2.locker_id AS locker_id_item,
                                            im.availability,
                                            i.item_from,
                                            i.locker_id,
                                            i.locker_location_id,
                                            i.item_size_id,
                                            isz.size_type,
                                            ll.location_name,
                                            ll.location_address
                                        FROM 
                                            item_management im
                                        LEFT JOIN  
                                            item_management_status ims ON im.item_mngt_status_id = ims.item_mngt_status_id
                                        LEFT JOIN  
                                            item i ON im.item_id = i.item_id
                                        LEFT JOIN  
                                            item_size isz ON i.item_size_id = isz.item_size_id
                                        LEFT JOIN 
                                            qrcode_recipient qr1 ON im.qrcode_recipient_id = qr1.qrcode_recipient_id
                                        LEFT JOIN 
                                            qrcode_delivery qr2 ON im.qrcode_delivery_id = qr2.qrcode_delivery_id 
                                        LEFT JOIN  
                                            locker l ON i.locker_id = l.locker_id
                                        LEFT JOIN  
                                            locker_location ll ON i.locker_location_id = ll.locker_location_id
                                        WHERE 
                                            im.item_mngt_id = '" . $item_mngt_id . "';";

                                $result = mysqli_query($conn, $sql);
                                $row = mysqli_fetch_array($result,MYSQLI_ASSOC);

                                $item_mngt_id = $row['item_mngt_id'];
                                $qrcode_recipient_id = $row['qrcode_recipient_id'];
                                $qrcode_delivery_id = $row['qrcode_delivery_id'];
                                $pic_id = $row['pic_id'];
                                $recipient_id = $row['recipient_id'];
                                $courier_id = $row['courier_id'];
                                $item_id = $row['item_id'];
                                $item_from = $row['item_from'];
                                $item_size_id = $row['item_size_id'];
                                $size_type = $row['size_type'];
                                $locker_location_id = $row['locker_location_id'];
                                $location_name = $row['location_name'];
                                $locker_id = $row['locker_id_item'];
                                $item_mngt_status_id = $row['item_mngt_status_id'];
                                $item_management_status = $row['item_management_status'];
                                $register_date = $row['register_date'];
                                $arrived_date = $row['arrived_date'];
                                $pickup_date = $row['pickup_date'];

                                
                                
                            ?>
                        <form method="post" action="function/update-item.php?qrcode_recipient_id=<?php echo $qrcode_recipient_id; ?>&qrcode_delivery_id=<?php echo $qrcode_delivery_id; ?>" enctype="multipart/form-data">
                            <div class="card-body">
                                
                            <div class="row">
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label for="item_mngt_id">Resit Id: </label>
                                            <input type="text" class="form-control" id="item_mngt_id" name="item_mngt_id" value="<?php echo $item_mngt_id; ?>" required readonly>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label for="picid">Person In Charge Id: </label>
                                            <input type="text" class="form-control" id="picid" name="picid" value="<?php echo $pic_id; ?>" required readonly onkeyup="validatePicid()">
                                            <span id="jpidError" class="errorss"></span>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label for="recipient_id">Recipient Id: </label>
                                            <input type="text" class="form-control" id="recipient_id" name="recipient_id" value="<?php echo $recipient_id; ?>" required onkeyup="validateRecipient_id()">
                                            <span id="recipient_idError" class="errorss"></span>
                                        </div>
                                    </div>
                                    
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label for="courier_id">Courier Id: </label>
                                            <input type="text" class="form-control" id="courier_id" name="courier_id" value="<?php echo $courier_id; ?>" required readonly>
                                            <span id="courier_idError" class="errorss"></span>
                                        </div>
                                    </div>
                                    
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label for="item_id">Item Id: </label>
                                            <input type="text" class = "form-control" id="item_id" name="item_id" value="<?php echo $item_id; ?>" required readonly/>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label for="item_from">Item From: </label>
                                            <input type="text" class="form-control" id="item_from" name="item_from" value="<?php echo $item_from; ?>" required onkeyup="validateItem_from()"/>
                                            <span id="item_fromError" class="errorss"></span>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label for="size_type">Size:</label><br/>
                                            <select class="custom-select" id="size_type" name="size_type">
                                                <option value="1" <?php echo ($item_size_id === '1') ? 'selected' : ''; ?>>S</option>
                                                <option value="2" <?php echo ($item_size_id === '2') ? 'selected' : ''; ?>>L</option>
                                                <!-- Add more options as needed -->
                                            </select>
                                            <span id="typeError" class="errorss"></span> <!-- Error message container -->
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label for="location_id">Location Name: </label>
                                            <select class="custom-select" id="location_id" name="location_id" >
                                            <option value='<?php echo "$locker_location_id";?>' selected><?php echo "$location_name";?></option>
                                                <?php  if ($userrole == '1'){
                                                    // Assuming $conn is your database connection
                                                    $query = "SELECT locker_location_id, location_name FROM locker_location WHERE availability = 1;";
                                                    $result = $conn->query($query);
                                                    if ($result && $result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $location_id = $row['locker_location_id'];
                                                            $address = $row['location_name'];
                                                            echo "<option value='$location_id'>$address</option>";
                                                        }
                                                    } else {
                                                        echo "<option value='' disabled>No locations available</option>";
                                                    }
                                                }

                                                
                                                // } else if ($userrole == '2' || $userrole == '3') {
                                    
                                                //     $sql9 = "SELECT jp_location_id FROM user WHERE user_id = $userid;";
                                                //     $result9 = mysqli_query($conn, $sql9);
                                                //     $row9 = mysqli_fetch_array($result9, MYSQLI_ASSOC);
                                                //     $location = $row9['jp_location_id'];
                                                //     $result9->close();
                                    
                                                //     $sql8 = "SELECT name FROM pickup_location WHERE pickupLocation_id = $location;";
                                                //     $result8 = mysqli_query($conn, $sql8);
                                                //     $row8 = mysqli_fetch_array($result8, MYSQLI_ASSOC);
                                                //     $address = $row8['name'];
                                                //     $result8->close();

                                                //     echo "<option value='$location_id'>$address</option>";
                                                // }
                                                // ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label for="locker_id">Locker Id: </label>
                                            <input type="text" class="form-control" id="locker_id" name="locker_id" value="<?php echo $locker_id; ?>" readonly required />
                                            <span id="locker_idError" class="errorss"></span>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label for="status">Status:</label><br/>
                                            <select class="custom-select" id="status" name="status" onchange="validateStatus()">
                                                <option value="1" <?php echo ($item_mngt_status_id === '1') ? 'selected' : ''; ?>>Pending</option>
                                                <option value="2" <?php echo ($item_mngt_status_id === '2') ? 'selected' : ''; ?>>Arrived</option>
                                                <option value="3" <?php echo ($item_mngt_status_id === '3') ? 'selected' : ''; ?>>Picked</option>
                                                <option value="4" <?php echo ($item_mngt_status_id === '4') ? 'selected' : ''; ?>>Waiting</option>
                                                <!-- Add more options as needed -->
                                            </select>
                                            <span id="statusError" class="errorss"></span> <!-- Error message container -->
                                        </div>
                                    </div>
                                    <?php
                                        // $register_date = date("Y-m-d\TH:i:s", strtotime($register_date));
                                        // $arrived_date = date("Y-m-d\TH:i:s", strtotime($arrived_date));
                                        // $pickup_date = date("Y-m-d\TH:i:s", strtotime($pickup_date));
                                    ?>

                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label for="register_date">Register Date and Time: </label>
                                            <input type="text" class="form-control" id="register_date" name="register_date" value="<?php echo $register_date; ?>" onkeyup="validateRegister_Date()">
                                            <span id="register_dateError" class="errorss"></span>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label for="arrived_date">Arrived Date and Time: </label>
                                            <input type="text" class="form-control" id="arrived_date" name="arrived_date" value="<?php echo $arrived_date; ?>" onkeyup="validateArrived_Date()">
                                            <span id="arrived_dateError" class="errorss"></span>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label for="pickup_date">Pickup Date and Time: </label>
                                            <input type="text" class="form-control" id="pickup_date" name="pickup_date" value="<?php echo $pickup_date; ?>" onkeyup="validatePickup_Date()">
                                            <span id="pickup_dateError" class="errorss"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer py-3" >
                                <div class="row">
                                    <div class="col-xl-6 col-md-6">
                                        <div class="small text-white"><a href="item-list.php" class="btn btn-primary btn-sm">Back</a></div>
                                    </div>
                                    <div class="col-xl-6 col-md-6">
                                        <div style="float:right;"><button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i>&nbsp;&nbsp;Update</button></div>
                                    </div>
                                </div>
                            </div>
                        <form>
                    </div>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include 'includecode/copyright.php'?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>


    <script>
        function validatePicid() {
            var picid = document.getElementById('picid').value;
            var picidError = document.getElementById('picidError');

            if (picid.trim() === '') {
                picidError.innerHTML = 'Pic Id is required';
            } else {
                picidError.innerHTML = '';
            }
        }

        function validateRecipient_id() {
            var recipient_id = document.getElementById('recipient_id').value;
            var recipient_idError = document.getElementById('recipient_idError');

            if (recipient_id.trim() === '') {
                recipient_idError.innerHTML = 'Receipient Id is required';
            } else {
                recipient_idError.innerHTML = '';
            }
        }

        function validateCourier_id() {
            var courier_id = document.getElementById('courier_id').value;
            var courier_idError = document.getElementById('courier_idError');

            if (courier_id.trim() === '') {
                courier_idError.innerHTML = 'Courier Id is required';
            } else {
                courier_idError.innerHTML = '';
            }
        }

        function validateItem_from() {
            var item_from = document.getElementById('item_from');
            var item_fromError = document.getElementById('item_fromError');

            if (item_from.value === '') {
                item_fromError.innerHTML = 'Please select a location';
            } else {
                item_fromError.innerHTML = '';
            }
        }

        function validateRegister_Date() {
            var register_date = document.getElementById('register_date');
            var register_dateError = document.getElementById('register_dateError');

            if (register_date.value === '') {
                register_dateError.innerHTML = 'Register Date is required';
            } else {
                register_dateError.innerHTML = '';
            }
        }

        function validateArrived_Date() {
            var arrived_date = document.getElementById('arrived_date');
            var arrived_dateError = document.getElementById('arrived_dateError');

            if (arrived_date.value === '') {
                arrived_dateError.innerHTML = 'Arrived Date is required';
            } else {
                arrived_dateError.innerHTML = '';
            }
        }

        function validatePickup_Date() {
            var pickup_date = document.getElementById('pickup_date');
            var pickup_dateError = document.getElementById('pickup_dateError');

            if (pickup_date.value === '') {
                pickup_dateError.innerHTML = 'Pickup Date is required';
            } else {
                pickup_dateError.innerHTML = '';
            }
        }

        function validateForm() {
            // Call all individual validation functions
            validatePicid();
            validateRecipient_id();
            validateCourier_id();
            validateItem_from();
            validateRegister_Date();
            validateArrived_Date();
            validatePickup_Date();  

            // Check if there are any validation errors
            var picidError = document.getElementById('picidError').innerHTML;
            var recipient_idError = document.getElementById('recipient_idError').innerHTML;
            var courier_idError = document.getElementById('courier_idError').innerHTML;
            var item_fromError = document.getElementById('item_fromError').innerHTML;
            var register_dateError = document.getElementById('register_dateError').innerHTML;
            var arrived_dateError = document.getElementById('arrived_dateError').innerHTML;
            var pickup_dateError = document.getElementById('pickup_dateError').innerHTML;

            if (picidError === '' && recipient_idError === '' && courier_idError === '' && item_fromError === '' && register_dateError === '' && arrived_dateError === '' && pickup_dateError === '') {
                return true; // Submit the form
            } else {
                return false; // Stop form submission
            }
        }
    </script>
    <!-- Foot -->
    <?php include 'includecode/foot.php' ?>
    <!-- Foot -->


</body>
</html>