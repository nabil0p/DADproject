<?php
session_start();

// Check if user is logged in, redirect to login page if not
if (!isset($_SESSION["id"])) {
    header("Location: login.php");
    exit;
}
$page = 'item-assign-register.php'; 
$screen_name = 'Register Item';

include 'db/db_connection.php'; // Include your database connection

?>

<!DOCTYPE html>
<html>
<head>
    <!-- Head -->
    <?php include 'includecode/head.php' ?>
    <!-- Head -->
</head>
<style>
    <?php include 'includecode/plusdesign.php' ?>
</style>

    
<body id="page-top">
    <?php
    // Check if 'error' parameter is set in the URL
    if (isset($_GET['error'])) {
        // Display an error message with the value of the 'error' parameter
        echo '<div id="alert-containers" class="alert alert-danger" role="alert">' . $_GET['error'] . '</div>';
        
    }

    // Check if 'error' parameter is set in the URL
    if (isset($_GET['success'])) {
        // Display an error message with the value of the 'error' parameter
        echo '<div id="alert-containers" class="alert alert-success" role="success">' . $_GET['success'] . '</div>';
        
    }
    
    ?>

    <script>
        // Wait for the DOM to be ready
        document.addEventListener("DOMContentLoaded", function() {
            // Set a timeout to hide the error message after 5 seconds
            setTimeout(function() {
                var alertContainer = document.getElementById('alert-containers');
                if (alertContainer) {
                    // Hide the error message by setting display to 'none'
                    alertContainer.style.display = 'none';
                }
            }, 3000); // 5000 milliseconds = 5 seconds
        });
    </script>
    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Side Nav -->
        <?php include 'function/navigation/sidenav.php' ?>
        <!-- Side Nav -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include 'function/navigation/topnav.php' ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">Register Item</h1>
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Register Item</h6>
                        </div>
                        <form method="post" action="function/add-assign-item.php" enctype="multipart/form-data" onsubmit="return validateForm()">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group">
                                                <label class="required" for="qldid">Customer Id (e.g R0001):</label>
                                                <input type="text" class="form-control" id="qldid" name="qldid" value="<?php echo isset($_GET['qldid']) ? $_GET['qldid'] : ''; ?>" onkeyup="validateQldid()">
                                                <span id="qldidError" class="errorss"></span>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group">
                                                <label class="required" for="itemfrom">Item From (Sender Address/Company):</label>
                                                <input type="text" class="form-control" id="itemfrom" name="itemfrom" value="<?php echo isset($_GET['itemfrom']) ? $_GET['itemfrom'] : ''; ?>" onkeyup="validateItemFrom()">
                                                <span id="itemfromError" class="errorss"></span>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group">
                                                <label class="required" for="lockerlocation">Locker Location:</label>
                                                <select class="custom-select" id="lockerlocation" name="lockerlocation" onchange="validateLockerlocation()">
                                                    <option value="">Please Select</option>
                                                    <?php
                                                    // Assuming you have a database connection established already
                                                    $sql = "SELECT * FROM locker_location WHERE availability = 1 ORDER BY locker_location_id asc";
                                                    $result = mysqli_query($conn, $sql);
                                                    while($row = mysqli_fetch_assoc($result)) {
                                                        $lockerLocationId = $row['locker_location_id'];
                                                        $locationName = $row['location_name'];
                                                        echo "<option value='" . $lockerLocationId . "'>" . $locationName . "</option>";
                                                    }
                                                    ?>
                                                </select>
                                                <span id="lockerlocationError" class="errorss"></span>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group">
                                                <label class="required" for="size">Size:</label><br/>
                                                <select class="custom-select" id="size" name="size">
                                                    <option value="1" <?php echo (isset($_GET['size']) && $_GET['size'] === '1') ? 'selected' : ''; ?>>S</option>
                                                    <option value="2" <?php echo (isset($_GET['size']) && $_GET['size'] === '2') ? 'selected' : ''; ?>>L</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer py-3">
                                    <div class="row">
                                        <div class="col-xl-6 col-md-6">
                                            <div class="small text-white">
                                                <a href="item-assign-list.php?" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i>&nbsp;&nbsp;View Assigment List</a>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-md-6">
                                            <div style="float:right;">
                                                <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i>&nbsp;&nbsp;Register Item</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include 'includecode/copyright.php'?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Foot -->
    <?php include 'includecode/foot.php' ?>
    <!-- Foot -->

    <script>
        function validateQldid() {
            var qldid = document.getElementById('qldid').value;
            var qldidError = document.getElementById('qldidError');

            if (qldid.trim() === '') {
                qldidError.innerHTML = 'Customer Id is required';
            } else {
                qldidError.innerHTML = '';
            }
        }
        function validateItemFrom() {
            var itemfrom = document.getElementById('itemfrom').value;
            var itemfromError = document.getElementById('itemfromError');

            if (itemfrom.trim() === '') {
                itemfromError.innerHTML = 'Item From is required';
            } else {
                itemfromError.innerHTML = '';
            }
        }
        function validateLockerlocation() {
            var lockerlocation = document.getElementById('lockerlocation').value;
            var lockerlocationError = document.getElementById('lockerlocationError');

            if (lockerlocation.trim() === '') {
                lockerlocationError.innerHTML = 'Item Name is required';
            } else {
                lockerlocationError.innerHTML = '';
            }
        }


        function validateForm() {
            // Call all individual validation functions
            validateQldid();
            validateItemFrom(); 
            validateLockerlocation();

            // Check if there are any validation errors
            var qldidError = document.getElementById('qldidError').innerHTML;
            var itemfromError = document.getElementById('itemfromError').innerHTML;
            var lockerlocationError = document.getElementById('lockerlocationError').innerHTML;

            if (qldidError === '' && itemfromError === '' && lockerlocationError === '') {
                return true; // Submit the form
            } else {
                return false; // Stop form submission
            }
        }
    </script>



</body>
</html>