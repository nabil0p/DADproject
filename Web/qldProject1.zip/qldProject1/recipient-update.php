<?php
// Start the session at the very beginning of the script
session_start();

// Check if user is logged in, redirect to login page if not
if (!isset($_SESSION["id"])) {
    header("Location: login.php");
    exit;
}

$page = 'recipient-update.php'; 
$screen_name = 'Customer Update';

$qldid = isset($_GET['qldid']) ? $_GET['qldid'] : '';

$roleid = isset($_SESSION["role_id"]) ? $_SESSION["role_id"] : ''; 

include 'db/db_connection.php'; // Include your database connection

// Buffer output to prevent 'headers already sent' errors
ob_start();
?>

<!DOCTYPE html>
<html>
<head>
    <!-- Head -->
    <?php include 'includecode/head.php'; ?>
    <!-- Head -->
</head>
<style>
    <?php include 'includecode/plusdesign.php'; ?>
</style>
    
<body id="page-top">
    <?php
    // Check if 'error' parameter is set in the URL
    if (isset($_GET['error'])) {
        // Display an error message with the value of the 'error' parameter
        echo '<div id="alert-containers" class="alert alert-danger" role="alert">' . $_GET['error'] . '</div>';
    }

    // Check if 'error' parameter is set in the URL
    if (isset($_GET['success'])) {
        // Display an error message with the value of the 'error' parameter
        echo '<div id="alert-containers" class="alert alert-success" role="success">' . $_GET['success'] . '</div>';
    }
    ?>

    <script>
        // Wait for the DOM to be ready
        document.addEventListener("DOMContentLoaded", function() {
            // Set a timeout to hide the error message after 5 seconds
            setTimeout(function() {
                var alertContainer = document.getElementById('alert-containers');
                if (alertContainer) {
                    // Hide the error message by setting display to 'none'
                    alertContainer.style.display = 'none';
                }
            }, 3000); // 3000 milliseconds = 3 seconds
        });
    </script>

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Side Nav -->
        <?php include 'function/navigation/sidenav.php'; ?>
        <!-- Side Nav -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include 'function/navigation/topnav.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <h1 class="h3 mb-4 text-gray-800">Customer's Profile</h1>
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Update Profile</h6>
                        </div>
                        <form method="post" action="function/update-customer.php?qldid=<?php echo $qldid; ?>" enctype="multipart/form-data" onsubmit="return validateForm()">
                            <div class="card-body">
                                <?php
                                $sql = "SELECT u.*, r.role_name as rolename FROM users u JOIN role r ON u.role_id = r.role_id WHERE qld_id = '$qldid'"; 
                                $result = mysqli_query($conn, $sql);
                                $row = mysqli_fetch_array($result, MYSQLI_ASSOC);

                                $username = $row['username'];
                                $password = $row['password'];
                                $phoneNumber = $row['phone_num'];
                                $icNumber = $row['ic_num'];
                                $emailAddress = $row['mail_address'];
                                $fullName = $row['full_name'];
                                $role = $row['rolename'];
                                $image = $row['image'];
                                ?>
                                <div class="row">
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label class="required" for="username">Username:</label>
                                            <input type="text" class="form-control" id="username" name="username" value="<?php echo $username; ?>" required readonly>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label class="required" for="fullname">Full Name:</label>
                                            <input type="text" class="form-control" id="fullname" name="fullname" value="<?php echo $fullName; ?>" required onkeyup="validateFullName()">
                                            <span id="fullnameError" class="errorss"></span>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label class="required" for="phonenumber">Phone Number:</label>
                                            <input type="text" class="form-control" id="phonenumber" name="phonenumber" value="<?php echo $phoneNumber; ?>" required onkeyup="validatePhoneNumber()">
                                            <span id="phonenumberError" class="errorss"></span>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label class="required" for="icnumber">IC Number:</label>
                                            <input type="text" class="form-control" id="icnumber" name="icnumber" value="<?php echo $icNumber; ?>" required onkeyup="validateICNumber()">
                                            <span id="icnumberError" class="errorss"></span>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label class="required" for="email">E-Mail:</label>
                                            <input type="text" class="form-control" id="email" name="email" value="<?php echo $emailAddress; ?>" required onkeyup="validateEmail()">
                                            <span id="emailError" class="errorss"></span>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label class="required" for="role">Role:</label>
                                            <input type="text" class="form-control" id="role" name="role" value="<?php echo $role; ?>" required readonly>
                                            <span id="roleError" class="errorss"></span>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">    
                                            <label class="required" for="image">Image:</label>
                                            <div class="image-container">
                                                <img id="preview-image" src="data:image/jpeg;base64,<?php echo htmlspecialchars(base64_encode($image), ENT_QUOTES, 'UTF-8'); ?>" />
                                            </div>
                                            <?php if ($roleid == 1) { echo '<input type="file" id="image" name="image" class="form-control" onchange="previewImage(this)">'; } ?>
                                            <script>
                                                function previewImage(input) {
                                                    var preview = document.getElementById('preview-image');
                                                    var file = input.files[0];
                                                    var reader = new FileReader();

                                                    reader.onloadend = function () {
                                                        preview.src = reader.result;
                                                    };

                                                    if (file) {
                                                        reader.readAsDataURL(file);
                                                    } else {
                                                        preview.src = "upload/QLD-logo-1.png"; // Default image or placeholder
                                                    }
                                                }
                                            </script>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer py-3">
                                <div class="row">
                                    <div class="col-xl-6 col-md-6">
                                        <div class="small text-white"><a href="recipient-list.php" class="btn btn-primary btn-sm">Back</a></div>
                                    </div>
                                    <div class="col-xl-6 col-md-6">
                                        <?php if ($roleid == 1) { echo '<div style="float:right;"><button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i>&nbsp;&nbsp;Update</button></div>'; } ?>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <?php 
                    if ($roleid == 1) {
                        echo '<div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Update Password</h6>
                                </div>
                                <form method="post" id="fpass" name="fpass" action="function/update-pascust.php?qldid=' . $qldid . '" enctype="multipart/form-data">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-xl-3 col-md-6">
                                                <div class="form-group">
                                                    <label class="required" for="password">Password:</label>
                                                    <input type="password" class="form-control" id="password" name="password" required onkeyup="validatePassword()">
                                                    <span id="passwordError" class="errorss"></span>
                                                </div>
                                            </div>
                                            <div class="col-xl-3 col-md-6">
                                                <div class="form-group">
                                                    <label class="required" for="repassword">Confirm Password:</label>
                                                    <input type="password" class="form-control" id="repassword" name="repassword" required onkeyup="validatePassword()">
                                                    <span id="confirmPasswordError" class="errorss"></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer py-3">
                                        <div class="row">
                                            <div class="col-xl-6 col-md-6">
                                                <div class="small text-white"><a href="recipient-list.php" class="btn btn-primary btn-sm">Back</a></div>
                                            </div>
                                            <div class="col-xl-6 col-md-6">
                                                <div style="float:right;"><button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i>&nbsp;&nbsp;Update</button></div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>';
                    }
                    ?>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include 'includecode/copyright.php'?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Foot -->
    <?php include 'includecode/foot.php' ?>
    <!-- Foot -->
</body>
</html>
<?php
// Flush the output buffer
ob_end_flush();
?>
