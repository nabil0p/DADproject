<?php
session_start();

// Check if user is logged in, redirect to login page if not
if (!isset($_SESSION["id"])) {
    header("Location: login.php");
    exit;
}
$page = 'item-list.php'; 
$screen_name = 'Item Management List';

$roleid = isset($_SESSION["role_id"]) ? $_SESSION["role_id"] : ''; 

include 'db/db_connection.php'; // Include your database connection

?>

<!DOCTYPE html>
<html>
<head>
    <!-- Head -->
    <?php include 'includecode/head.php' ?>
    <!-- Head -->
</head>
<style>
    <?php include 'includecode/plusdesign.php' ?>
</style>
    
<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Side Nav -->
        <?php include 'function/navigation/sidenav.php' ?>
        <!-- Side Nav -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include 'function/navigation/topnav.php' ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">Management List</h1>
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Search</h6>
                        </div>
                        <form method="GET" id="myForm" action="#!" enctype="multipart/form-data">
                            <div class="card-body">
                                <div class="row">
                                <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                                <label for="resitid">Resit Id:</label><br/>
                                                <input type="text" class="form-control" id="resitid" name="resitid" value="<?php echo isset($_GET['resitid']) ? $_GET['resitid'] : ''; ?>">
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                                <label for="picid">PIC Id:</label><br/>
                                                <input type="text" class="form-control" id="picid" name="picid" value="<?php echo isset($_GET['picid']) ? $_GET['picid'] : ''; ?>">
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                                <label for="courierid">Courier Id:</label><br/>
                                                <input type="text" class="form-control" id="courierid" name="courierid" value="<?php echo isset($_GET['courierid']) ? $_GET['courierid'] : ''; ?>">
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                                <label for="recipientid">Recipient Id:</label><br/>
                                                <input type="text" class="form-control" id="recipientid" name="recipientid" value="<?php echo isset($_GET['recipientid']) ? $_GET['recipientid'] : ''; ?>">
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                                <label for="itemid">Item Id:</label><br/>
                                                <input type="text" class="form-control" id="itemid" name="itemid" value="<?php echo isset($_GET['itemid']) ? $_GET['itemid'] : ''; ?>">
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                                <label for="lockerid">Locker Id:</label><br/>
                                                <input type="text" class="form-control" id="lockerid" name="lockerid" value="<?php echo isset($_GET['lockerid']) ? $_GET['lockerid'] : ''; ?>">
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                                <label for="startdate">Start Register Date:</label><br/>
                                                <input type="date" class="form-control" id="startdate" name="startdate" value="<?php echo isset($_GET['startdate']) ? $_GET['startdate'] : ''; ?>">
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                                <label for="enddate">End Register Date:</label><br/>
                                                <input type="date" class="form-control" id="enddate" name="enddate" value="<?php echo isset($_GET['enddate']) ? $_GET['enddate'] : ''; ?>">
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                                <label for="dstartdate">Start Delivery Date:</label><br/>
                                                <input type="date" class="form-control" id="dstartdate" name="dstartdate" value="<?php echo isset($_GET['dstartdate']) ? $_GET['dstartdate'] : ''; ?>">
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                                <label for="denddate">End Delivery Date:</label><br/>
                                                <input type="date" class="form-control" id="denddate" name="denddate" value="<?php echo isset($_GET['denddate']) ? $_GET['denddate'] : ''; ?>">
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                                <label for="pnstartdate">Start Pickup Date:</label><br/>
                                                <input type="date" class="form-control" id="pnstartdate" name="pnstartdate" value="<?php echo isset($_GET['pnstartdate']) ? $_GET['pnstartdate'] : ''; ?>">
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                                <label for="pnenddate">End Pickup Date:</label><br/>
                                                <input type="date" class="form-control" id="pnenddate" name="pnenddate" value="<?php echo isset($_GET['pnenddate']) ? $_GET['pnenddate'] : ''; ?>">
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label for="status">Status:</label><br/>
                                            <select class="custom-select" id="status" name="status">
                                                <option value="">Please Select</option>
                                                <option value="4" <?php echo (isset($_GET['status']) && $_GET['status'] === '3') ? 'selected' : ''; ?>>Waiting</option>
                                                <option value="1" <?php echo (isset($_GET['status']) && $_GET['status'] === '1') ? 'selected' : ''; ?>>On The Way</option>
                                                <option value="2" <?php echo (isset($_GET['status']) && $_GET['status'] === '2') ? 'selected' : ''; ?>>Arrived</option>
                                                <option value="3" <?php echo (isset($_GET['status']) && $_GET['status'] === '3') ? 'selected' : ''; ?>>Picked</option>
                                                <!-- Add more options as needed -->
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer py-3" >
                                <div class="row">
                                    <div class="col-xl-6 col-md-6">
                                        <div><button type="submit" onclick="resetForm()" class="btn btn-primary btn-sm" name="carian" value="carian" id="carian">Reset</button></div>
                                    </div>
                                    <script>
                                        function resetForm() {
                                            document.forms["myForm"]["resitid"].value = '';
                                            document.forms["myForm"]["picid"].value = '';
                                            document.forms["myForm"]["courierid"].value = '';
                                            document.forms["myForm"]["recipientid"].value = '';
                                            document.forms["myForm"]["itemid"].value = '';
                                            document.forms["myForm"]["lockerid"].value = '';
                                            document.forms["myForm"]["startdate"].value = '';
                                            document.forms["myForm"]["enddate"].value = '';
                                            document.forms["myForm"]["dstartdate"].value = '';
                                            document.forms["myForm"]["denddate"].value = '';
                                            document.forms["myForm"]["pnstartdate"].value = '';
                                            document.forms["myForm"]["pnenddate"].value = '';
                                            document.forms["myForm"]["status"].value = '';
                                        }
                                    </script>
                                    <div class="col-xl-6 col-md-6">
                                        <div style="float:right;"><button type="submit" class="btn btn-primary btn-sm" name="carian" value="carian" id="carian"><i class="fa fa-search"></i>&nbsp;&nbsp;Search</button></div>
                                    </div>
                                </div>
                            </div>
                        <form>
                    </div>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Item Management List</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <?Php
                                        $sql = "SELECT 
                                                im.item_mngt_id,
                                                im.pic_id,
                                                im.item_id,
                                                im.item_mngt_status_id,
                                                ims.status_name AS item_management_status,                                                
                                                im.register_date,
                                                im.pickup_date,
                                                im.arrived_date,
                                                im.qrcode_recipient_id,
                                                qr1.recipient_id AS recipient_id,
                                                im.qrcode_delivery_id,
                                                qr2.courier_id AS courier_id,
                                                qr2.locker_id AS locker_id_item,
                                                im.availability,
                                                i.item_from,
                                                i.locker_id,
                                                i.item_size_id,
                                                isz.size_type
                                            FROM 
                                                item_management im
                                            JOIN 
                                                item_management_status ims ON im.item_mngt_status_id = ims.item_mngt_status_id
                                            JOIN 
                                                item i ON im.item_id = i.item_id
                                            JOIN 
                                                item_size isz ON i.item_size_id = isz.item_size_id
                                            LEFT JOIN 
                                                qrcode_recipient qr1 ON im.qrcode_recipient_id = qr1.qrcode_recipient_id
                                            LEFT JOIN 
                                                qrcode_delivery qr2 ON im.qrcode_delivery_id = qr2.qrcode_delivery_id WHERE availability = 1 "; 
                                                    
                                            // Filtering listing
                                            if (isset($_GET['carian'])) {
                                                $resitid=$_GET['resitid'];
                                                $picid=$_GET['picid'];
                                                $courierid=$_GET['courierid'];
                                                $recipientid=$_GET['recipientid'];
                                                $itemid=$_GET['itemid'];
                                                $lockerid=$_GET['lockerid'];
                                                $startdate=$_GET['startdate'];
                                                $enddate=$_GET['enddate'];
                                                $dstartdate=$_GET['dstartdate'];
                                                $denddate=$_GET['denddate'];
                                                $pnstartdate=$_GET['pnstartdate'];
                                                $pnenddate=$_GET['pnenddate'];
                                                $status=$_GET['status'];

                                                if($resitid!=""){
                                                    $sql .= " AND im.item_mngt_id LIKE '%$resitid%'";
                                                } 

                                                if($picid!=""){
                                                    $sql .= " AND im.pic_id LIKE '%$picid%'";
                                                } 

                                                if($courierid!=""){
                                                    $sql .= " AND courier_id LIKE '%$courierid%'";
                                                }
                                                
                                                if($recipientid!=""){
                                                    $sql .= " AND qr1.recipient_id LIKE '%$recipientid%'";
                                                }

                                                if($itemid!=""){
                                                    $sql .= " AND im.item_id LIKE '%$itemid%'";
                                                }
                                                if($lockerid!=""){
                                                    $sql .= " AND locker_id_item LIKE '%$lockerid%'";
                                                }

                                                if($startdate!="" && $enddate!=""){
                                                    $sql .= " AND im.register_date BETWEEN '$startdate' AND '$enddate'";
                                                } elseif($startdate!=""){
                                                    $sql .= " AND im.register_date >= '$startdate'";
                                                } elseif($enddate!=""){
                                                    $sql .= " AND im.register_date <= '$enddate'";
                                                }

                                                if($dstartdate!="" && $denddate!=""){
                                                    $sql .= " AND im.arrived_date BETWEEN '$dstartdate' AND '$denddate'";
                                                } elseif($dstartdate!=""){
                                                    $sql .= " AND im.arrived_date >= '$dstartdate'";
                                                } elseif($denddate!=""){
                                                    $sql .= " AND im.arrived_date <= '$denddate'";
                                                }

                                                if($pnstartdate!="" && $pnenddate!=""){
                                                    $sql .= " AND im.pickup_date BETWEEN '$pnstartdate' AND '$pnenddate'";
                                                } elseif($pnstartdate!=""){
                                                    $sql .= " AND im.pickup_date >= '$pnstartdate'";
                                                } elseif($pnenddate!=""){
                                                    $sql .= " AND im.pickup_date <= '$pnenddate'";
                                                }

                                                if($status!=""){
                                                    $sql .= " AND im.item_mngt_status_id LIKE '%$status%'";
                                                }

                                            $sql .= " ORDER BY im.register_date DESC;";
                                            $statement = $sql;

                                                //print $sql;
                                                $result = mysqli_query($conn, $sql);

                                            }else{
                                                //set semula tanpa filtering
                                                $sql = "SELECT 
                                                im.item_mngt_id,
                                                im.pic_id,
                                                im.item_id,
                                                im.item_mngt_status_id,
                                                ims.status_name AS item_management_status,                                                
                                                im.register_date,
                                                im.pickup_date,
                                                im.arrived_date,
                                                im.qrcode_recipient_id,
                                                qr1.recipient_id AS recipient_id,
                                                im.qrcode_delivery_id,
                                                qr2.courier_id AS courier_id,
                                                qr2.locker_id AS locker_id_item,
                                                im.availability,
                                                i.item_from,
                                                i.locker_id,
                                                i.item_size_id,
                                                isz.size_type
                                            FROM 
                                                item_management im
                                            JOIN 
                                                item_management_status ims ON im.item_mngt_status_id = ims.item_mngt_status_id
                                            JOIN 
                                                item i ON im.item_id = i.item_id
                                            JOIN 
                                                item_size isz ON i.item_size_id = isz.item_size_id
                                            LEFT JOIN 
                                                qrcode_recipient qr1 ON im.qrcode_recipient_id = qr1.qrcode_recipient_id
                                            LEFT JOIN 
                                                qrcode_delivery qr2 ON im.qrcode_delivery_id = qr2.qrcode_delivery_id WHERE availability = 1 ORDER BY im.item_mngt_status_id DESC;"; 
                                                
                                                $result = mysqli_query($conn, $sql);
                                                //print $sql;
                                            }

                                    
                                        ?>
                                        <thead>
                                            <tr>
                                                <th width="25px">Num.</th>
                                                <th width="100px">Resit Id</th>
                                                <th width="100px">PIC Id</th>
                                                <th width="120px">Recipient Id</th>
                                                <th width="100px">Courier Id</th>
                                                <th width="100px">Item Id</th>
                                                <th width="100px">Item From</th>
                                                <th width="100px">Locker Id</th>
                                                <th>Register Date</th>
                                                <th>Delivery Date</th>
                                                <th>Pickup Date</th>
                                                <th width="80px">Status</th>
                                                <th width="80px">Action</th>
                                            </tr>
                                        </thead>
                                        <tfoot>
                                            <tr>
                                                <th width="25px">Num.</th>
                                                <th width="100px">Resit Id</th>
                                                <th width="100px">PIC Id</th>
                                                <th width="120px">Recipient Id</th>
                                                <th width="100px">Courier Id</th>
                                                <th width="100px">Item Id</th>
                                                <th width="100px">Item From</th>
                                                <th width="100px">Locker Id</th>
                                                <th>Register Date</th>
                                                <th>Delivery Date</th>
                                                <th>Pickup Date</th>
                                                <th>Status</th>
                                                <th width="100px">Action</th>
                                            </tr>
                                        </tfoot>

                                        <tbody>
                                            <?php $x=1;
                                                while ($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){

                                                    $item_mngt_id = $row['item_mngt_id'];
                                                    $qldid = $row['pic_id'];
                                                    $recipient_id = $row['recipient_id'];
                                                    $courier_id = $row['courier_id'];
                                                    $item_id = $row['item_id'];
                                                    $item_from = $row['item_from'];
                                                    $locker_id = $row['locker_id_item'];
                                                    $register_date = $row['register_date'];
                                                    $arrived_date = $row['arrived_date'];
                                                    $pickup_date = $row['pickup_date'];
                                                    $item_management_status = $row['item_management_status'];
    
                                                    if ($item_management_status === "On The Way" ){
                                                        $color = "#ffbb33";
                                                    }
                                                    if ($item_management_status === "Arrived" ){
                                                        $color = "#33b5e5";
                                                    }
                                                    if ($item_management_status === "Picked" ){
                                                        $color = "#00c851";
                                                    }

                                                    if ($item_management_status === "Waiting" ){
                                                        $color = "#ED4337";
                                                    }
    
    
                                                ?>
                                                <tr>
                                                    <td style="vertical-align: middle;"><?php echo $x;?></td>
                                                    <td style="vertical-align: middle;"><?php echo $item_mngt_id; ?></td>
                                                    <td style="vertical-align: middle;"><?php echo $qldid; ?></td>
                                                    <td style="vertical-align: middle;"><?php echo $recipient_id; ?></td>
                                                    <td style="vertical-align: middle;"><?php echo $courier_id; ?></td>
                                                    <td style="vertical-align: middle;"><?php echo $item_id; ?></td>
                                                    <td style="vertical-align: middle;"><?php echo $item_from; ?></td>
                                                    <td style="vertical-align: middle;"><?php echo $locker_id; ?></td>
                                                    <td style="vertical-align: middle;"><?php echo $register_date; ?></td>
                                                    <td style="vertical-align: middle;"><?php echo $arrived_date; ?></td>
                                                    <td style="vertical-align: middle;"><?php echo $pickup_date; ?></td>
                                                    <td style="vertical-align: middle;">
                                                        <div class="btn btn-sm" style="background-color: <?php echo $color; ?>;color: white; margin-top: 3px; cursor: default; pointer-events: none; user-select: none;">
                                                            <?php echo $item_management_status; ?>
                                                        </div>
                                                    </td>
                                                    <td style="vertical-align: middle;">
                                                        <a href="item-update.php?item_mngt_id=<?php echo $item_mngt_id; ?>" class="btn btn-info btn-sm"style="margin-top:3px;"><i class="fas fa-edit"></i></a>
                                                        <?php if($roleid == 1 ){echo '<button class="btn btn-danger btn-sm" style="margin-top:3px;" data-toggle="modal" data-target="#deleteModal'. $item_mngt_id .'"><i class="fas fa-trash-alt"></i></button>';} ?>
                                                        <!-- Delete Modal -->
                                                        <div class="modal fade" id="deleteModal<?php echo $item_mngt_id; ?>" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
                                                            <div class="modal-dialog" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="deleteModalLabel">Delete Customer</h5>
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <!-- Add your delete confirmation message here -->
                                                                        <p>Are you sure you want to delete this item: <?php echo $item_mngt_id; ?>?</p>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                        <a href="function/delete-item.php?item_mngt_id=<?php echo $item_mngt_id; ?>" class="btn btn-danger">Delete</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                                    </td>
                                                </tr>
                                            <?php $x++;} ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include 'includecode/copyright.php'?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Foot -->
    <?php include 'includecode/foot.php' ?>
    <!-- Foot -->


</body>
</html>