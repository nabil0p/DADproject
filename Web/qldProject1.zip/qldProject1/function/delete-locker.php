<?php
session_start();

// Check if user is logged in, redirect to login page if not
if (!isset($_SESSION["id"])) {
    header("Location: ../index.php");
    exit;
}

$locker_id = isset($_GET['locker_id']) ? $_GET['locker_id'] : '';

include '../db/db_connection.php'; // Include your database connection

// Insert the new user into the database with the determined role_id
$dlt = "UPDATE locker SET availability  = 2 WHERE locker_id = '$locker_id';";

$aa  = mysqli_query($conn, $dlt);

if ($conn->query($dlt) === TRUE) {
    header("Location: ../locker-list.php");
    exit;
} else {
    echo "Error adding user: " . $conn->error;
}

$conn->close();
?>

