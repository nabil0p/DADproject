<?php
session_start();

if (!isset($_SESSION["id"])) {
    header("Location: ../index.php");
    exit;
}

$userid = $_SESSION["id"];
$userrole = $_SESSION["role_id"];

include '../db/db_connection.php'; // Include your database connection

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $qrcode_recipient_id = $_GET["qrcode_recipient_id"];
    $qrcode_delivery_id = $_GET["qrcode_delivery_id"];
    $pic_id = $_POST["picid"];
    $recipient_id = $_POST["recipient_id"];
    $item_mngt_id = $_POST["item_mngt_id"];
    $item_id = $_POST["item_id"];
    $item_from = $_POST["item_from"];
    $size_type = $_POST["size_type"];
    $location_id = $_POST["location_id"];
    $status = $_POST["status"];
    $register_date = $_POST["register_date"];
    $arrived_date = $_POST["arrived_date"];
    $pickup_date = $_POST["pickup_date"];

    // Check if any of the fields are empty
    if (empty($recipient_id) || empty($item_mngt_id) || empty($pic_id) || empty($item_id) || empty($item_from) || empty($size_type) || empty($location_id) || empty($status) || empty($register_date) || empty($arrived_date) || empty($pickup_date)) {
        header("Location: ../item-update.php?item_mngt_id=$item_mngt_id&error=input cannot be empty");
        exit();
    }

    // Check if the user specified by recipient_id exists
    $rolepic = 3;
    $checkUserQuery = "SELECT * FROM users WHERE qld_id = ? and role_id = ?";
    $stmt = $conn->prepare($checkUserQuery);
    $stmt->bind_param("si", $recipient_id, $rolepic);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        // User doesn't exist, exit the code or redirect to an error page
        header("Location: ../item-update.php?item_mngt_id=$item_mngt_id&error='Recipient Id not found'");
        exit();
    }

    // Handle special case for empty dates and set them to NULL
    $register_date = ($register_date == '0000-00-00 00:00:00') ? NULL : date('Y-m-d H:i:s', strtotime($register_date));
    $arrived_date = ($arrived_date == '0000-00-00 00:00:00') ? NULL : date('Y-m-d H:i:s', strtotime($arrived_date));
    $pickup_date = ($pickup_date == '0000-00-00 00:00:00') ? NULL : date('Y-m-d H:i:s', strtotime($pickup_date));

    // Perform the UPDATE operation on qrcode_recipient table
    $updateQueryQrcode_recipient = "UPDATE qrcode_recipient 
                                    SET recipient_id = ? 
                                    WHERE qrcode_recipient_id = ?";
    $stmt = $conn->prepare($updateQueryQrcode_recipient);
    $stmt->bind_param("ss", $recipient_id, $qrcode_recipient_id); 
    $updateResultQrcode_recipient = $stmt->execute();

    // Perform the UPDATE operation on item table
    $updateQueryItem = "UPDATE item 
                        SET item_from = ?, 
                            item_size_id = ?, 
                            locker_location_id = ? 
                        WHERE item_id = ?";
    $stmt = $conn->prepare($updateQueryItem);
    $stmt->bind_param("ssss", $item_from, $size_type, $location_id, $item_id); 
    $updateResultItem = $stmt->execute();

    // Perform the UPDATE operation on item_management table
    $updateQueryDate = "UPDATE item_management
                        SET item_mngt_status_id = ?, 
                            register_date = ?, 
                            arrived_date = ?, 
                            pickup_date = ?
                        WHERE item_mngt_id = ?";
    $stmt = $conn->prepare($updateQueryDate);
    $stmt->bind_param("issss", $status, $register_date, $arrived_date, $pickup_date, $item_mngt_id);
    $updateResultDate = $stmt->execute();

    if ($updateResultQrcode_recipient && $updateResultItem && $updateResultDate) {
        header("Location: ../item-update.php?item_mngt_id=$item_mngt_id&success=Item Details Updated Successfully");
        exit();
    } else {
        echo "Error updating item: " . $conn->error;
    }
}

$conn->close();
?>
