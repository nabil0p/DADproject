<?php

// Check if user is logged in, redirect to login page if not
if (!isset($_SESSION["id"])) {
    header("Location: ../index.php");
    exit;
}

// Fetch user's name from the database
    $user_id = $_SESSION["id"];
    $sql = "SELECT username, role_id FROM users WHERE LOWER(QLD_id) = LOWER('$user_id')";
    $result = mysqli_query($conn, $sql) or die(mysqli_error($conn));
    $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
    $user_role = $row ['role_id'];
    $user_name = $row["username"];
?>

<?php  if (($user_role == '1')){ ?>
        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
                <div class="sidebar-brand-icon ">
                        <img class="rounded-circle" src="assets/QLD-logo-1.jpg" alt="Logo" style="width:30px;height:30px;"/>
                </div>
                <div class="sidebar-brand-text mx-3">QLocker-D</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item <?php if($page == "index.php") {echo 'active';} ?> ">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Employee
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item <?php if($page == "location-register.php" || $page == "location-list.php" || $page == "location-update.php") {echo 'active';} ?> ">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#locations"
                    aria-expanded="true" aria-controls="locations">
                    <i class="fas fa-fw fa-home"></i>
                    <span>Location</span>
                </a>
                <div id="locations" class="collapse <?php if($page == "location-register.php" || $page == "location-list.php" || $page == "location-update.php") {echo 'show';} ?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Location's Sections:</h6>
                        <a class="collapse-item" href="location-register.php">Add New</a>
                        <a class="collapse-item" href="location-list.php">List</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item <?php if($page == "locker-register.php" || $page == "locker-list.php" || $page == "locker-update.php") {echo 'active';} ?> ">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#lockers"
                    aria-expanded="true" aria-controls="lockers">
                    <i class="fas fa-fw fa-box"></i>
                    <span>Locker</span>
                </a>
                <div id="lockers" class="collapse <?php if($page == "locker-register.php" || $page == "locker-list.php" || $page == "locker-update.php") {echo 'show';} ?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Locker's Sections:</h6>
                        <a class="collapse-item" href="locker-register.php">Add New</a>
                        <a class="collapse-item" href="locker-list.php">List</a>
                    </div>
                </div>
            </li>
            
            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item <?php if($page == "employee-register.php" || $page == "employee-list.php" || $page == "employee-update.php") {echo 'active';} ?>">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#employees"
                    aria-expanded="true" aria-controls="employees">
                    <i class="fas fa-fw fa-user"></i>
                    <span>Staff</span>
                </a>
                <div id="employees" class="collapse <?php if($page == "employee-register.php" || $page == "employee-list.php" || $page == "employee-update.php") {echo 'show';} ?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Staff's Sections:</h6>
                        <a class="collapse-item" href="employee-register.php">Add New</a>
                        <a class="collapse-item" href="employee-list.php">List</a>
                    </div>
                </div>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Management
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item <?php if($page == "item-register.php" || $page == "item-list.php" || $page == "item-update.php" || $page == "item-assign-register.php"|| $page == "item-assign-list.php" || $page == "item-assign-staff.php") {echo 'active';} ?>">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#items"
                    aria-expanded="true" aria-controls="items">
                    <i class="fas fa-fw fa-folder"></i>
                    <span>Item</span>
                </a>
                <div id="items" class="collapse <?php if($page == "item-register.php" || $page == "item-list.php" || $page == "item-update.php" || $page == "item-assign-register.php"|| $page == "item-assign-list.php" || $page == "item-assign-staff.php" ) {echo 'show';} ?>" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Item's Sections:</h6>
                        <a class="collapse-item" href="item-assign-register.php">Register Item</a>
                        <a class="collapse-item" href="item-assign-list.php">Item Assign List</a>
                        <a class="collapse-item" href="item-register.php">Assign Item</a>
                        <a class="collapse-item" href="item-list.php">Management List</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Tables -->
            <li class="nav-item <?php if($page == "recipient-list.php" || $page == "recipient-update.php") {echo 'active';} ?>">
                <a class="nav-link" href="recipient-list.php">
                    <i class="fas fa-fw fa-user"></i>
                    <span>Customer List</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->
<?php  } ?>