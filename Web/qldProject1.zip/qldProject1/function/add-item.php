<?php
session_start();

if (!isset($_SESSION["id"])) {
    header("Location: ../index.php");
    exit;
}


$user_id = $_SESSION["id"];

$userrole= $_SESSION["role_id"];

include '../db/db_connection.php'; // Include your database connection

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $qldid = $_POST["qldid"];
    $lockerlocation = $_POST["lockerlocation"];
    $courierid = $_POST["courierid"];
    $size = $_POST["size"];
    $itemfrom = $_POST["itemfrom"];

    // Perform checks on the sanitized values
    if (empty($qldid) || empty($lockerlocation) || empty($courierid)|| empty($itemfrom)|| empty($size)) {
        // Handle validation errors, for example, redirect to the form page with an error message
        header("Location: ../item-register.php?error=Invalid Input Data");
        exit();
    }

    

    // // Validate and handle image upload
    // if (isset($_FILES["image"]) && $_FILES["image"]["error"] == UPLOAD_ERR_OK) {
    //     $imageData = file_get_contents($_FILES["image"]["tmp_name"]);

    //     // Check if the file is an image (adjust as needed based on allowed image types)
    //     $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
    //     $fileType = mime_content_type($_FILES["image"]["tmp_name"]);

    //     if (!in_array($fileType, $allowedTypes)) {
    //         // Handle invalid image type
    //         header("Location: ../item-register.php?error=Invalid Image Type");
    //         exit();
    //     }

    //     // Continue with the rest of your code for processing the form data...
    // } else {
    //     // Handle cases where the image file is not uploaded successfully
    //     header("Location: ../item-register.php?error=Error Uploading The Image File");
    //     exit();
    // }

    $roleId = 3;
    // Check if the user specified by jpid exists
    $checkUserQuery = "SELECT * FROM users WHERE qld_id = ? and role_id = ?";
    $stmt = $conn->prepare($checkUserQuery);
    $stmt->bind_param("ss", $qldid, $roleId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        // User doesn't exist, exit the code or redirect to an error page
        header("Location: ../item-register.php?error=The User not found&qldid=$qldid&itemfrom=$itemfrom&size=$size&courierid=$courierid&lockerlocation=$lockerlocation");
        exit();
    }

    // Check if the user specified by jpid exists
    $checkCourier = "SELECT * FROM users WHERE qld_id = ?";
    $stmt2 = $conn->prepare($checkCourier);
    $stmt2->bind_param("s", $courierid);
    $stmt2->execute();
    $result123 = $stmt2->get_result();

    if ($result123 && $result123->num_rows > 0) {
        $row_courier = $result->fetch_assoc();
        $username = $row_courier["username"];
    } else {
        $username = "0"; // Default value in case of no result
    }

    // // Handle image file upload
    // if (isset($_FILES["image"]) && $_FILES["image"]["error"] == UPLOAD_ERR_OK) {
    //     $imageData = file_get_contents($_FILES["image"]["tmp_name"]);

    //     // You should validate and sanitize user inputs here

    //     // Generate the tracking number based on the item type
    //     if ($itemType_id == 1) {
    //         // If item type is Document (ID 1), set the tracking number to '-'
    //         $tracknum = '-';
    //     } elseif ($itemType_id == 2) {
    //         if($tracknum == ''){
    //             header("Location: ../item-register.php?error1=Please Enter Tracking Number");
    //             exit();
    //         }
    //     }

        
        // Fetch the current maximum value from the 'item' table
        $query = "SELECT MAX(CAST(SUBSTRING(item_id, 4) AS UNSIGNED)) AS max_id FROM item";
        $result = $conn->query($query);

        if ($result && $row = $result->fetch_assoc()) {
            $maxId = $row['max_id'];
            // Increment the maximum value
            $nextId = $maxId + 1;

            // Format the next ID with leading zeros
            $item_id = 'I' . str_pad($nextId, 4, '0', STR_PAD_LEFT);
        } else {
            // Default value if there are no existing records
            $item_id = 'I0001';
        }

        // Use $jp_item_id in your SQL query or wherever needed

        // Insert the new item into the database using prepared statement
        $stmt = $conn->prepare("INSERT INTO item (item_id, item_from, locker_location_id, item_size_id) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sssi", $item_id, $itemfrom, $lockerlocation, $size);

        if ($stmt->execute()) {

            // Fetch the current maximum value from the 'payment' table
            $query = "SELECT MAX(CAST(SUBSTRING(qrcode_recipient_id, 4) AS UNSIGNED)) AS max_id FROM qrcode_recipient";
            $result = $conn->query($query);

            if ($result && $row = $result->fetch_assoc()) {
                $maxId = $row['max_id'];
                // Increment the maximum value
                $nextId = $maxId + 1;

                // Format the next ID with leading zeros
                $qrcode_recipient_id = 'QCR' . str_pad($nextId, 4, '0', STR_PAD_LEFT);
            } else {
                // Default value if there are no existing records
                $qrcode_recipient_id = 'QCR0001';
            }
            
            $sql2 = "INSERT INTO qrcode_recipient (qrcode_recipient_id, recipient_id) VALUES ('$qrcode_recipient_id', '$qldid');";
            $result2 = mysqli_query($conn, $sql2); 

            // Fetch the current maximum value from the 'due_date' table
            $query = "SELECT MAX(CAST(SUBSTRING(qrcode_delivery_id, 4) AS UNSIGNED)) AS max_id FROM qrcode_delivery";
            $result = $conn->query($query);

            if ($result && $row = $result->fetch_assoc()) {
                $maxId = $row['max_id'];
                // Increment the maximum value
                $nextId = $maxId + 1;

                // Format the next ID with leading zeros
                $qrcode_delivery_id = 'QCD' . str_pad($nextId, 4, '0', STR_PAD_LEFT);
            } else {
                // Default value if there are no existing records
                $qrcode_delivery_id = 'QCD0001';
            }

            $statusqrdelivery = "0";
            $sql3 = "INSERT INTO qrcode_delivery (qrcode_delivery_id, courier_id, status) VALUES ('$qrcode_delivery_id', '$courierid', '$statusqrdelivery');";
            $result3 = mysqli_query($conn, $sql3); 

            
            date_default_timezone_set('Asia/Kuala_Lumpur');
            $currentDate = date("Y-m-d H:i:s");

            // Fetch the current maximum value from the 'item_management' table
            $query = "SELECT MAX(CAST(SUBSTRING(item_mngt_id, 4) AS UNSIGNED)) AS max_id FROM item_management";
            $result = $conn->query($query);

            if ($result && $row = $result->fetch_assoc()) {
                $maxId = $row['max_id'];
                // Increment the maximum value
                $nextId = $maxId + 1;

                // Format the next ID with leading zeros
                $item_mngt_id = 'IM' . str_pad($nextId, 4, '0', STR_PAD_LEFT);
            } else {
                // Default value if there are no existing records
                $item_mngt_id = 'IM0001';
            }
            $availability = 1;
            $item_mngt_status_id = 1;
            $sql4 = "INSERT INTO item_management (item_mngt_id, pic_id, item_id, item_mngt_status_id, register_date, qrcode_recipient_id,qrcode_delivery_id, availability)
                        VALUES (
                            '$item_mngt_id',
                            '$user_id',
                            '$item_id',
                            '$item_mngt_status_id',
                            '$currentDate',
                            '$qrcode_recipient_id',
                            '$qrcode_delivery_id',
                            '$availability'
                        );";
                        
            $result4 = mysqli_query($conn, $sql4); 

            header("Location: ../item-register.php?success=Item Registered Successfully!");
            
            // Send OneSignal Notification

            // Send push notification using OneSignal
        $api_url = 'https://onesignal.com/api/v1/notifications';
        $app_id = '5873f180-bc70-4eef-aec0-2337ca6c04bd';
        $api_key = 'ZTdmYjVmYzQtOTJlZC00NDMzLWExMjgtZWU1OTQwNjdhYTll';

        $contents = array('en' => "Hello, {$username}! You have New 1 pending item(s) to deliver. Please check your pending list.");

        $data = array(
            'app_id' => $app_id,
            'include_external_user_ids' => array($courierid), // This should be an array
            'contents' => $contents,
        );

        // Convert data to JSON
        $data_string = json_encode($data);

        // Set up cURL for making the request
        $ch = curl_init($api_url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Authorization: Basic ' . $api_key,
        ));
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Execute cURL request
        $result = curl_exec($ch);

        // Check for cURL errors
        if (curl_errno($ch)) {
            echo 'Curl error: ' . curl_error($ch);
            // Handle the error as needed
            exit();
        } else {
            // Close cURL session
            curl_close($ch);
        }

        // Check if the notification was sent successfully
        $responseData = json_decode($result, true);

        if (isset($responseData['id'])) {
            // Notification sent successfully
            header("Location: ../item-register.php?success=Item Assign to Staff is Success!");
        } else {
            // Error sending notification
            header("Location: ../item-register.php?error=Notification Error");
        }

        }

        $stmt->close();

    } else {
        header("Location: ../item-register.php?error=Error Uploading Image File");
    }

    $conn->close();
?>
