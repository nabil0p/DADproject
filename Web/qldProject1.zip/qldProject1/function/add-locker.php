<?php
session_start();

// Check if user is logged in, redirect to login page if not
if (!isset($_SESSION["id"])) {
    header("Location: ../index.php");
    exit;
}

include '../db/db_connection.php'; // Include your database connection

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Validate location
    $reglocker = trim($_POST["reglocker"]);
    $lockersize = trim($_POST["lockersize"]);
    $lockerlocation = trim($_POST["lockerlocation"]);

    if (empty($reglocker)) {
        header("Location: ../location-register.php?error=Locker Number is Required&reglocker=$reglocker");
        exit;
    }

    if (empty($lockersize)) {
        header("Location: ../location-register.php?error=Locker Size is Required&reglocker=$reglocker");
        exit;
    }

    if (empty($lockerlocation)) {
        header("Location: ../location-register.php?error=Locker location is Required&reglocker=$reglocker");
        exit;
    }

    // Retrieve the latest ID from the database
    $sql = "SELECT MAX(CAST(SUBSTRING(locker_id, 2) AS UNSIGNED)) AS max_id FROM locker";
    $result = $conn->query($sql);

    if ($result && $row = $result->fetch_assoc()) {
        $max_id = $row['max_id'];
        $new_locker_id = 'Q' . str_pad($max_id + 1, 4, '0', STR_PAD_LEFT);
    } else {
        $new_locker_id = 'Q0001'; // Set initial ID if no records exist
    }

    $locker_status = 2;
    $locker_availability = 1;
    $availability = 1;

    // Prepare and execute the SQL statement
    $stmt = $conn->prepare("INSERT INTO locker (locker_id, locker_name, locker_size, locker_location_id, locker_status_id, locker_availability_id, availability) VALUES (?, ?, ?, ?, ?, ?, ?)");

    if ($stmt) {
        $stmt->bind_param("ssssiii", $new_locker_id, $reglocker, $lockersize, $lockerlocation, $locker_status, $locker_availability, $availability);

        // Execute the statement
        if ($stmt->execute()) {
            header("Location: ../locker-register.php?success=Locker Added Successfully");
            exit;
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }

    $conn->close();
}
?>
