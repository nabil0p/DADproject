<?php
session_start();

// Check if user is logged in, redirect to login page if not
if (!isset($_SESSION["id"])) {
    header("Location: ../index.php");
    exit;
}

$item_mngt_id = isset($_GET['item_mngt_id']) ? $_GET['item_mngt_id'] : '';
$user_id = $_SESSION["id"];


include '../db/db_connection.php'; // Include your database connection

$dlt = "UPDATE item_management SET availability  = 2 WHERE item_mngt_id = '$item_mngt_id';";
$aa  = mysqli_query($conn, $dlt);

if ($aa === TRUE) {
    header("Location: ../item-list.php");
    exit;
} else {
    echo "Error updating item availability: " . mysqli_error($conn);
}

mysqli_close($conn);
?>

