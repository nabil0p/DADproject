<?php
session_start();

include '../db/db_connection.php'; // Include your database connection

try {
    // Check if the users is logged in, redirect to the login page if not
    if (!isset($_SESSION["id"])) {
        header("Location: ../index.php");
        exit;
    }

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $userName = $_POST["username"];
        $password = $_POST["password"];
        $phoneNumber = $_POST["phonenumber"];
        $icNumber = $_POST["icnumber"];
        $emailAddress = $_POST["email"];
        $fullName = $_POST["fullname"];
        $role = $_POST["role"];

        // Check if any of the fields is empty
        if (empty($userName) || empty($password) || empty($phoneNumber) || empty($icNumber) || empty($emailAddress) || empty($fullName) || empty($role)) {
            header("Location: ../employee-register.php?error=Input Can't Be Empty");
            exit();
        }

        // Validate password
        if (!preg_match('/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[^a-zA-Z\d]).{6,}$/', $password)) {
            header("Location: ../employee-register.php?error=Invalid Password");
            exit();
        }

        // Validate phone number (adjust the regex as needed)
        if (!preg_match("/^[0-9]{10,11}$/", $phoneNumber)) {
            header("Location: ../employee-register.php?error=Invalid Phone Number");
            exit();
        }

        // Validate IC number (adjust the regex as needed)
        if (!preg_match("/^[0-9]{12}$/", $icNumber)) {
            header("Location: ../employee-register.php?error=Invalid IC Number");
            exit();
        }

        // Validate email address
        if (!filter_var($emailAddress, FILTER_VALIDATE_EMAIL)) {
            header("Location: ../employee-register.php?error=Invalid Email");
            exit();
        }

        // Validate image file
        // Check if the file is uploaded
        if (empty($_FILES["image"]["tmp_name"]) || !file_exists($_FILES["image"]["tmp_name"])) {
            header("Location: ../employee-register.php?error=Image File is Required");
            exit;
        }

        //Check file type
        $allowedFileTypes = ['image/jpeg', 'image/png', 'image/jpg'];
        $uploadedFileType = $_FILES["image"]["type"];

        if (!in_array($uploadedFileType, $allowedFileTypes)) {
            header("Location: ../employee-register.php?error=Invalid File Type. Only JPEG, PNG, and JPG are allowed.");
            exit;
        }

        //Check file size (max 5 MB)
        $maxFileSize = 5 * 1024 * 1024; // 5 MB in bytes
        if ($_FILES["image"]["size"] > $maxFileSize) {
            header("Location: ../employee-register.php?error=File size exceeds the maximum limit of 5 MB.");
            exit;
        }

        // $image = file_get_contents($_FILES["image"]["tmp_name"]);
        $availability = 1;

        // Check if the username already exists
        $checkUsernameQuery = "SELECT qld_id FROM users WHERE username = ?";
        $checkUsernameStmt = $conn->prepare($checkUsernameQuery);
        $checkUsernameStmt->bind_param("s", $userName);
        $checkUsernameStmt->execute();
        $checkUsernameResult = $checkUsernameStmt->get_result();

        if ($checkUsernameResult->num_rows > 0) {
            // Username already exists, handle the error
            header("Location: ../employee-register.php?error=Username already exists");
            exit();
        }

        if($role === "1"){
            // Fetch the current maximum value from the 'user' table using prepared statements
            $query = "SELECT MAX(CAST(SUBSTRING(qld_id, 3) AS UNSIGNED)) AS max_id FROM users WHERE role_id = 1;";
            $stmt = $conn->prepare($query);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result && $row = $result->fetch_assoc()) {
                $maxId = $row['max_id'];
                // Increment the maximum value
                $nextId = $maxId + 1;

                // Format the next ID with leading zeros
                $qld_id = 'A' . str_pad($nextId, 4, '0', STR_PAD_LEFT);
            } else {
                // Default value if there are no existing records
                $qld_id = 'A0001';
            }
        }

        if($role === "2"){
            // Fetch the current maximum value from the 'user' table using prepared statements
            $query = "SELECT MAX(CAST(SUBSTRING(qld_id, 3) AS UNSIGNED)) AS max_id FROM users WHERE role_id = 2;";
            $stmt = $conn->prepare($query);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result && $row = $result->fetch_assoc()) {
                $maxId = $row['max_id'];
                // Increment the maximum value
                $nextId = $maxId + 1;

                // Format the next ID with leading zeros
                $qld_id = 'C' . str_pad($nextId, 4, '0', STR_PAD_LEFT);
            } else {
                // Default value if there are no existing records
                $qld_id = 'C0001';
            }
        }

        if($role === "3"){
            // Fetch the current maximum value from the 'user' table using prepared statements
            $query = "SELECT MAX(CAST(SUBSTRING(qld_id, 3) AS UNSIGNED)) AS max_id FROM users WHERE role_id = 3;";
            $stmt = $conn->prepare($query);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result && $row = $result->fetch_assoc()) {
                $maxId = $row['max_id'];
                // Increment the maximum value
                $nextId = $maxId + 1;

                // Format the next ID with leading zeros
                $qld_id = 'R' . str_pad($nextId, 4, '0', STR_PAD_LEFT);
            } else {
                // Default value if there are no existing records
                $qld_id = 'R0001';
            }
            
        }

        $hashPassword = password_hash($password, PASSWORD_DEFAULT);

        $image = file_get_contents($_FILES["image"]["tmp_name"]);

        // Use prepared statements for the insertion query
        $insertQuery = "INSERT INTO users (qld_id, username, password, phone_num, ic_num, mail_address, full_name, role_id, availability, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insertQuery);

        if ($stmt) {
            $stmt->bind_param("sssssssiis", $qld_id, $userName, $hashPassword, $phoneNumber, $icNumber, $emailAddress, $fullName, $role, $availability, $image);

            // Execute the statement
            if ($stmt->execute()) {

                if($role === "2"){
                $courier_qld_id=$qld_id;
                $courier_availability_id = '1';

                $sql = "INSERT INTO courier_details (courier_id, availability_id)
                    VALUES ('$courier_qld_id', '$courier_availability_id')";
                    if ($conn->query($sql) === TRUE) {
                        // echo "New record created successfully";
                        // exit();
                    } else {
                        // echo "Error: " . $sql . "<br>" . $conn->error;
                        // exit();
                    }
                }

            // Close the statement
            $stmt->close();

            header("Location: ../employee-register.php?success=New Employee Added Successfully");
            exit();
        } else {
            // Close the statement
            $stmt->close();
            header("Location: ../employee-register.php?error=Error Adding Employee");
            exit();
        }
        } else {
            // Close the statement
            header("Location: ../employee-register.php?error=Error Preparing Statement");
            exit();
        }


        


    }
} catch (Exception $e) {
    header("Location: ../employee-register.php?error=" . urlencode($e->getMessage()));
    exit();
} finally {
    // Close the database connection
    $conn->close();
}
?>