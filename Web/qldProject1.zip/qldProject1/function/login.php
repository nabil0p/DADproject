<?php
include '../db/db_connection.php';
session_start();

// Check if form was submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);

    // Fetch user data from the database, including hashed password and role_id
    $sql = "SELECT qld_id,username,role_id,password FROM users WHERE LOWER(username) = LOWER('$username')";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        
        if (password_verify($password, $row["password"])) {
           
            if ($row["role_id"] == 1) {
                // Admin role
                $_SESSION["id"] = $row["qld_id"];
                $_SESSION["username"] = $row["username"];
                $_SESSION["role_id"] = $row["role_id"];
                header("Location: ../index.php");
                exit;
            } else {
                header("Location: ../login.php?error=Unauthorized access");
            }
        } else {
            header("Location: ../login.php?error=Login Invalid");
        }
    } else {
        header("Location: ../login.php?error=Login Invalid");
    }

    $conn->close();
}
?>