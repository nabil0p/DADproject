<?php
session_start();

// Check if user is logged in, redirect to login page if not
if (!isset($_SESSION["id"])) {
    header("Location: ../index.php");
    exit;
}

$qldid = isset($_GET['qldid']) ? $_GET['qldid'] : '';
$user_id = $_SESSION["id"];

include '../sb/db_connection.php'; // Include your database connection

// Insert the new user into the database with the determined role_id
$dlt = "UPDATE users SET availability  = 2 WHERE qld_id = '$qldid';";

$aa  = mysqli_query($conn, $dlt);

if ($conn->query($dlt) === TRUE) {
    header("Location: ../recipient-list.php");
    exit;
} else {
    echo "Error deleting user: " . $conn->error;
}

$conn->close();
?>