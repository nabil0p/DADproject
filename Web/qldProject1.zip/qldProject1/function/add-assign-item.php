<?php
session_start();

if (!isset($_SESSION["id"])) {
    header("Location: ../index.php");
    exit;
}


$user_id = $_SESSION["id"];

$userrole= $_SESSION["role_id"];

include '../db/db_connection.php'; // Include your database connection

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $qldid = $_POST["qldid"];
    $lockerlocation = $_POST["lockerlocation"];
    $size = $_POST["size"];
    $itemfrom = $_POST["itemfrom"];

    // Perform checks on the sanitized values
    if (empty($qldid) || empty($lockerlocation) || empty($itemfrom)|| empty($size)) {
        // Handle validation errors, for example, redirect to the form page with an error message
        header("Location: ../item-assign-register.php?error=Invalid Input Data");
        exit();
    }

    

    $roleId = 3;
    // Check if the user specified by jpid exists
    $checkUserQuery = "SELECT * FROM users WHERE qld_id = ? and role_id = ?";
    $stmt = $conn->prepare($checkUserQuery);
    $stmt->bind_param("ss", $qldid, $roleId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        // User doesn't exist, exit the code or redirect to an error page
        header("Location: ../item-assign-register.php?error=The User not found&qldid=$qldid&itemfrom=$itemfrom&size=$size&lockerlocation=$lockerlocation");
        exit();
    }


        
        // Fetch the current maximum value from the 'item' table
        $query = "SELECT MAX(CAST(SUBSTRING(item_id, 4) AS UNSIGNED)) AS max_id FROM item";
        $result = $conn->query($query);

        if ($result && $row = $result->fetch_assoc()) {
            $maxId = $row['max_id'];
            // Increment the maximum value
            $nextId = $maxId + 1;

            // Format the next ID with leading zeros
            $item_id = 'I' . str_pad($nextId, 4, '0', STR_PAD_LEFT);
        } else {
            // Default value if there are no existing records
            $item_id = 'I0001';
        }

        // Use $jp_item_id in your SQL query or wherever needed

        // Insert the new item into the database using prepared statement
        $stmt = $conn->prepare("INSERT INTO item (item_id, item_from, locker_location_id, item_size_id) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sssi", $item_id, $itemfrom, $lockerlocation, $size);

        if ($stmt->execute()) {

            // Fetch the current maximum value from the 'payment' table
            $query = "SELECT MAX(CAST(SUBSTRING(qrcode_recipient_id, 4) AS UNSIGNED)) AS max_id FROM qrcode_recipient";
            $result = $conn->query($query);

            if ($result && $row = $result->fetch_assoc()) {
                $maxId = $row['max_id'];
                // Increment the maximum value
                $nextId = $maxId + 1;

                // Format the next ID with leading zeros
                $qrcode_recipient_id = 'QCR' . str_pad($nextId, 4, '0', STR_PAD_LEFT);
            } else {
                // Default value if there are no existing records
                $qrcode_recipient_id = 'QCR0001';
            }
            
            $sql2 = "INSERT INTO qrcode_recipient (qrcode_recipient_id, recipient_id) VALUES ('$qrcode_recipient_id', '$qldid');";
            $result2 = mysqli_query($conn, $sql2); 


            // Fetch the current maximum value from the 'due_date' table
            $query = "SELECT MAX(CAST(SUBSTRING(qrcode_delivery_id, 4) AS UNSIGNED)) AS max_id FROM qrcode_delivery";
            $result = $conn->query($query);

            if ($result && $row = $result->fetch_assoc()) {
                $maxId = $row['max_id'];
                // Increment the maximum value
                $nextId = $maxId + 1;

                // Format the next ID with leading zeros
                $qrcode_delivery_id = 'QCD' . str_pad($nextId, 4, '0', STR_PAD_LEFT);
            } else {
                // Default value if there are no existing records
                $qrcode_delivery_id = 'QCD0001';
            }

            $statusqrdelivery = "0";
            $sql3 = "INSERT INTO qrcode_delivery (qrcode_delivery_id) VALUES ('$qrcode_delivery_id');";
            $result3 = mysqli_query($conn, $sql3); 

            
            date_default_timezone_set('Asia/Kuala_Lumpur');
            $currentDate = date("Y-m-d H:i:s");

            // Fetch the current maximum value from the 'item_management' table
            $query = "SELECT MAX(CAST(SUBSTRING(item_mngt_id, 4) AS UNSIGNED)) AS max_id FROM item_management";
            $result = $conn->query($query);

            if ($result && $row = $result->fetch_assoc()) {
                $maxId = $row['max_id'];
                // Increment the maximum value
                $nextId = $maxId + 1;

                // Format the next ID with leading zeros
                $item_mngt_id = 'IM' . str_pad($nextId, 4, '0', STR_PAD_LEFT);
            } else {
                // Default value if there are no existing records
                $item_mngt_id = 'IM0001';
            }
            $availability = 1;
            $item_mngt_status_id = 4;

            $sql4 = "INSERT INTO item_management (item_mngt_id, pic_id, item_id, item_mngt_status_id, register_date, qrcode_recipient_id,qrcode_delivery_id, availability)
                        VALUES (
                            '$item_mngt_id',
                            '$user_id',
                            '$item_id',
                            '$item_mngt_status_id',
                            '$currentDate',
                            '$qrcode_recipient_id',
                            '$qrcode_delivery_id',
                            '$availability'
                        );";
                        
            $result4 = mysqli_query($conn, $sql4); 

            header("Location: ../item-assign-register.php?success=Item Registered Successfully!");
        }

        $stmt->close();

    } else {
        header("Location: ../item-assign-register.php?error=Error Uploading Image File");
    }

    $conn->close();
?>
