<?php
session_start();

// Check if user is logged in, redirect to login page if not
if (!isset($_SESSION["id"])) {
    header("Location: ../index.php");
    exit;
}

$user_id = $_SESSION["id"];
$qldid = isset($_GET['qldid']) ? $_GET['qldid'] : '';

include '../db/db_connection.php'; // Include your database connection


if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Handle text input fields
    $username = $_POST["username"];
    $phoneNumber = $_POST["phonenumber"];
    $icNumber = $_POST["icnumber"];
    $emailAddress = $_POST["email"];
    $fullName = $_POST["fullname"];

    // Check if any of the text input fields is empty
    if (empty($username) || empty($phoneNumber) || empty($icNumber) || empty($emailAddress) || empty($fullName)) {
        header("Location: ../recipient-update.php?qldid=$qldid&error=Input Can't Be Empty");
        exit();
    }

    // Validate phone number
    if (!preg_match("/^[0-9]{10,11}$/", $phoneNumber)) {
        header("Location: ../recipient-update.php?qldid=$qldid&error=Invalid Phone Number");
        exit();
    }

    // Validate email address
    if (!filter_var($emailAddress, FILTER_VALIDATE_EMAIL)) {
        header("Location: ../recipient-update.php?qldid=$qldid&error=Invalid Email Address");
        exit();
    }

    // Validate IC number (Assuming a simple format)
    if (!preg_match("/^[0-9]{12}$/", $icNumber)) {
        header("Location: ../recipient-update.php?qldid=$qldid&error=Invalid IC Number");
        exit();
    }

    // Update the user profile information
    $upd = "UPDATE users 
            SET phone_num = '$phoneNumber', ic_num = '$icNumber', mail_address = '$emailAddress', full_name = '$fullName'
            WHERE username = '$username';";
    $result = mysqli_query($conn, $upd);

    if ($result) {
        // Handle file upload for the image
        if ($_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $image = file_get_contents($_FILES["image"]["tmp_name"]);
            $updateImageQuery = "UPDATE users SET image = ? WHERE username = ?";
            
            $stmt = $conn->prepare($updateImageQuery);
            $stmt->bind_param("ss", $image, $username);
            $stmt->send_long_data(0, $image);
            $stmt->execute();
        }

        header("Location: ../recipient-update.php?qldid=$qldid&success=Recipient Details Updated Successful");
        exit;
    } else {
        echo "Error updating user Recipient: " . $conn->error;
    }

}

$conn->close();
?>
