<?php
session_start();

if (!isset($_SESSION["id"])) {
    header("Location: ../index.php");
    exit;
}

include '../db/db_connection.php'; // Include your database connection

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $itemMngtId = $_POST["itemMngtId"];
    $courierid = $_POST["courierid"];
    $username = $_POST["username"];

    $username = ucfirst($username);

    // Split the string into an array
    $itemMngtIdArray = explode(',', $itemMngtId);

    $idCount = count($itemMngtIdArray);

    // Quote each item and join back into a string
    $itemMngtIdStr = implode(',', array_map(function($id) { return "'$id'"; }, $itemMngtIdArray));

    $sql1 = "UPDATE item_management SET item_mngt_status_id = 1 WHERE item_mngt_id IN ($itemMngtIdStr)";

    if ($conn->query($sql1) === TRUE) {
        //echo "Record updated successfully in item_management table";
    } else {
        header("Location: ../item-assign-list.php?error=Update Item Management Error");
        exit();
    }

    $sql2 = "UPDATE qrcode_delivery SET courier_id = '$courierid', status = '0' WHERE qrcode_delivery_id IN (SELECT qrcode_delivery_id FROM item_management WHERE item_mngt_id IN ($itemMngtIdStr))";

    if ($conn->query($sql2) === TRUE) {
        
        // Send push notification using OneSignal
        $api_url = 'https://onesignal.com/api/v1/notifications';
        $app_id = '5873f180-bc70-4eef-aec0-2337ca6c04bd';
        $api_key = 'ZTdmYjVmYzQtOTJlZC00NDMzLWExMjgtZWU1OTQwNjdhYTll';

        $contents = array('en' => "Hello, {$username}! You have New {$idCount} pending item(s) to deliver. Please check your pending list.");

        $data = array(
            'app_id' => $app_id,
            'include_external_user_ids' => array($courierid), // This should be an array
            'contents' => $contents,
        );

        // Convert data to JSON
        $data_string = json_encode($data);

        // Set up cURL for making the request
        $ch = curl_init($api_url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Authorization: Basic ' . $api_key,
        ));
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Execute cURL request
        $result = curl_exec($ch);

        // Check for cURL errors
        if (curl_errno($ch)) {
            echo 'Curl error: ' . curl_error($ch);
            // Handle the error as needed
            exit();
        } else {
            // Close cURL session
            curl_close($ch);
        }

        // Check if the notification was sent successfully
        $responseData = json_decode($result, true);

        if (isset($responseData['id'])) {
            // Notification sent successfully
            header("Location: ../item-assign-list.php?success=Item Assign to Staff is Success!");
        } else {
            // Error sending notification
            header("Location: ../item-assign-list.php?error=Notification Error");
        }

    } else {
        header("Location: ../item-assign-list.php?error=Error Item Assign to Staff");
    }

    $conn->close();

}