<?php
session_start();

// Check if user is logged in, redirect to login page if not
if (!isset($_SESSION["id"])) {
    header("Location: ../index.php");
    exit;
}

include '../db/db_connection.php'; // Include your database connection


if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Handle text input fields
    $locker_id = $_POST["locker_id"];
    $locker_name = $_POST["locker_name"];
    $locker_size = $_POST["locker_size"];
    $locker_location_id = $_POST["locker_location_id"];
    $locker_status_id = $_POST["locker_status_id"];
    $locker_availability = $_POST["locker_availability"];

    // Check if any of the text input fields is empty
    if (empty($locker_id) || empty($locker_name) || empty($locker_size) || empty($locker_location_id) || empty($locker_status_id)|| empty($locker_availability)) {
        header("Location: ../manager-update.php?locker_id=$locker_id&error=Input Can't Be Empty");
        exit();
    }


    // Update the user profile information
    $upd = "UPDATE locker 
            SET locker_name = '$locker_name', locker_size = '$locker_size', locker_location_id = '$locker_location_id', locker_status_id = '$locker_status_id', locker_availability_id = '$locker_availability'
            WHERE locker_id = '$locker_id';";
    $result = mysqli_query($conn, $upd);

    if ($result) {
        header("Location: ../locker-update.php?locker_id=$locker_id&success=Locker Details Updated Successful");
        exit;
    } else {
        echo "Error updating locker: " . $conn->error;
    }

}

$conn->close();
?>