<?php
session_start();

// Check if user is logged in, redirect to login page if not
if (!isset($_SESSION["id"])) {
    header("Location: index.php");
    exit;
}
$page = 'locker-list.php'; 
$screen_name = 'Locker List';

include 'db/db_connection.php'; // Include your database connection

?>

<!DOCTYPE html>
<html>
<head>
    <!-- Head -->
    <?php include 'includecode/head.php' ?>
    <!-- Head -->
    
</head>
<style>
    <?php include 'includecode/plusdesign.php' ?>
</style>
    
<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Side Nav -->
        <?php include 'function/navigation/sidenav.php' ?>
        <!-- Side Nav -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include 'function/navigation/topnav.php' ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">Locker's List</h1>
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Search</h6>
                        </div>
                        <form method="GET" id="myForm" action="locker-list.php" enctype="multipart/form-data">
                            <div class="card-body">
                                <div class="row">
                                <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label for="lockerid">Locker ID:</label>
                                            <input type="text" class="form-control" id="lockerid" name="lockerid" value="<?php echo isset($_GET['lockerid']) ? $_GET['lockerid'] : ''; ?>">
                
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label for="reglocker">Locker Name:</label>
                                            <input type="text" class="form-control" id="reglocker" name="reglocker" value="<?php echo isset($_GET['reglocker']) ? $_GET['reglocker'] : ''; ?>">
                
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label for="lockersize">Locker Size:</label><br/>
                                            <select class="custom-select" id="lockersize" name="lockersize" >
                                                <option value="">Please Select</option>
                                                <option value="S" <?php echo (isset($_GET['lockersize']) && $_GET['lockersize'] === 'S') ? 'selected' : ''; ?>>Small</option>
                                                <option value="L" <?php echo (isset($_GET['lockersize']) && $_GET['lockersize'] === 'L') ? 'selected' : ''; ?>>Large</option>
                                                <!-- Add more options as needed -->
                                            </select>
                                            <span id="lockersizeError" class="errorss"></span>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label for="lockerlocation">Locker Location: </label>
                                            <select class="custom-select" id="lockerlocation" name="lockerlocation" >
                                                <option value=''>Please Select</option>
                                                <?php
                                                // Assuming $conn is your database connection
                                                $query = "SELECT locker_location_id, location_name , location_address FROM locker_location WHERE availability = 1;";
                                                $result = $conn->query($query);

                                                if ($result && $result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $location_id = $row['locker_location_id'];
                                                        $address = $row['location_name'];
                                                        echo "<option value='$location_id'";
                                                        echo (isset($_GET['lockerlocation']) && $_GET['lockerlocation'] === $location_id) ? 'selected' : '';
                                                        echo ">$address</option>";
                                                    }
                                                } else {
                                                    echo "<option value='' disabled>No locations available</option>";
                                                }

                                                // Close the result set
                                                $result->close();
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label for="lockerstatus">Locker Status:</label><br/>
                                            <select class="custom-select" id="lockerstatus" name="lockerstatus" >
                                                <option value="">Please Select</option>
                                                <option value="1" <?php echo (isset($_GET['lockerstatus']) && $_GET['lockerstatus'] === '1') ? 'selected' : ''; ?>>Open</option>
                                                <option value="2" <?php echo (isset($_GET['lockerstatus']) && $_GET['lockerstatus'] === '2') ? 'selected' : ''; ?>>Close</option>
                                                <!-- Add more options as needed -->
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer py-3" >
                                <div class="row">
                                    <div class="col-xl-6 col-md-6">
                                        <div><button type="submit" onclick="resetForm()" class="btn btn-primary btn-sm" name="carian" value="carian" id="carian">Reset</button></div>
                                    </div>
                                    <script type="text/javascript">
                                        function resetForm() {
                                            document.forms["myForm"]["lockerid"].value = '';
                                            document.forms["myForm"]["reglocker"].value = '';
                                            document.forms["myForm"]["lockersize"].value = '';
                                            document.forms["myForm"]["lockerlocation"].value = '';
                                            document.forms["myForm"]["lockerstatus"].value = '';
                                        }
                                    </script>
                                    <div class="col-xl-6 col-md-6">
                                        <div style="float:right;"><button type="submit" class="btn btn-primary btn-sm" name="carian" value="carian" id="carian"><i class="fa fa-search"></i>&nbsp;&nbsp;Search</button></div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Locker List</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <?Php
                                        $sql = "SELECT * FROM locker INNER JOIN locker_location ON locker.locker_location_id = locker_location.locker_location_id WHERE locker.availability = 1 "; 
                                        //filtering listing
                                        if (isset($_GET['carian'])) {
                                            $lockerid=$_GET['lockerid'];
                                            $reglocker=$_GET['reglocker'];
                                            $lockersize=$_GET['lockersize'];
                                            $lockerlocation=$_GET['lockerlocation'];
                                            $lockerstatus=$_GET['lockerstatus'];
                                        
                                            if($lockerid!=""){
                                                $sql= $sql . " and locker_id LIKE '%$lockerid%'";
                                            } 
                                            if($reglocker!=""){
                                                $sql= $sql . " and locker_name LIKE '%$reglocker%'";
                                            }
                                        
                                            if($lockersize!=""){
                                                $sql= $sql . " and locker_size LIKE '%$lockersize%'";
                                            }
                                        
                                            if($lockerlocation!=""){
                                                $sql= $sql . " and locker.locker_location_id LIKE '%$lockerlocation%'";
                                            }
                                        
                                            if($lockerstatus!=""){
                                                $sql= $sql . " and locker_status_id = '$lockerstatus'";
                                            }
                                        
                                            $sql= $sql . " ORDER BY locker_id asc";          
                                            //print $sql;
                                            $result = mysqli_query($conn, $sql);
                                            $rec_count = mysqli_num_rows($result);
                                        } else {
                                            //set semula tanpa filtering
                                            $sql = "SELECT * FROM locker INNER JOIN locker_location ON locker.locker_location_id = locker_location.locker_location_id WHERE locker.availability = 1  ORDER BY locker.locker_id asc"; 
                                            $result = mysqli_query($conn, $sql);
                                            //print $sql;
                                        }
                                
                                    ?>
                                    <thead>
                                        <script>
                                        function checkAll(bx) {
                                            var cbs = document.getElementsByTagName('input');
                                            for(var i=0; i < cbs.length; i++) {
                                                if(cbs[i].type == 'checkbox') {
                                                cbs[i].checked = bx.checked;
                                                }
                                            }
                                        }</script>
                                        <tr>
                                            <!-- <th style="width:25px;">&nbsp;&nbsp;<input type="checkbox" onclick="checkAll(this)"></th> -->
                                            <th style="width:50px;">Num.</th>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Size</th>
                                            <th>Address</th>
                                            <th>User Use</th>
                                            <th>Status</th>
                                            <th>Availability</th>
                                            <th>QR Id</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <!-- <th style="width:25px;">&nbsp;&nbsp;<input type="checkbox" onclick="checkAll(this)"></th> -->
                                            <th style="width:50px;">Num.</th>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Size</th>
                                            <th>Address</th>
                                            <th>User Use</th>
                                            <th>Status</th>
                                            <th>Availability</th>
                                            <th>QR Id</th>
                                            <th>Action</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php $x=1;
                                            while ($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){
                                            $locker_id = $row['locker_id'];
                                            $locker_name = $row['locker_name'];
                                            $locker_size = $row['locker_size'];
                                            $user_use = $row['user_use'];
                                            $locker_address = $row['location_name'];
                                            $locker_status = $row['locker_status_id'];
                                            $locker_availability = $row['locker_availability_id'];
                                            $qrCodePass = $row['qrCodePass'];

                                            if($locker_status === "1"){
                                                $locker_status = "Open";
                                                $colorS = "#ED4337";
                                            }
                                            if($locker_status === "2"){
                                                $locker_status = "Close";
                                                $colorS = "#00c851";
                                            }

                                            if($locker_availability === "1"){
                                                $locker_availability = "Has Item";
                                                $colorA = "#33b5e5";
                                            }
                
                                            if($locker_availability === "2"){
                                                $locker_availability = "Empty";
                                                $colorA = "#ffbb33";
                                            }

                                            if ($user_use == ""){
                                                $user_use = "Nobody";
                                            }
                                            
                                            ?>
                                            <tr>
                                                <!-- <td>&nbsp;&nbsp;<input type="checkbox" name="name1" /></td> -->
                                                <td style="text-align: center;"><?php echo $x;?></td>
                                                <td><?php echo $locker_id; ?></td>
                                                <td><?php echo $locker_name; ?></td>
                                                <td><?php echo $locker_size; ?></td>
                                                <td><?php echo $locker_address; ?></td>
                                                <td><?php echo $user_use; ?></td> 
                                                <td>
                                                    <div class="btn btn-sm" style="background-color: <?php echo $colorS; ?>;color: white; margin-top: 3px; cursor: default; pointer-events: none; user-select: none;">
                                                        <?php echo $locker_status; ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="btn btn-sm" style="background-color: <?php echo $colorA; ?>;color: white; margin-top: 3px; cursor: default; pointer-events: none; user-select: none;">
                                                        <?php echo $locker_availability; ?>
                                                    </div>
                                                </td>
                                                <td><?php echo $qrCodePass; ?></td>
                                                <td> 
                                                    <a href="locker-update.php?locker_id=<?php echo $locker_id; ?>" class="btn btn-info btn-sm" style="margin-top:3px;"><i class="fas fa-edit"></i></a>
                                                    <button class="btn btn-danger btn-sm" style="margin-top:3px;" data-toggle="modal" data-target="#deleteModal<?php echo $locker_id; ?>"><i class="fas fa-trash"></i></button>
                                                    <div class="modal fade" id="deleteModal<?php echo $locker_id; ?>" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
                                                        <div class="modal-dialog" role="document">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="deleteModalLabel">Delete Location</h5>
                                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <!-- Add your delete confirmation message here -->
                                                                    <p>Are you sure you want to delete <?php echo $locker_id; ?> ?</p>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                    <a href="function/delete-locker.php?locker_id=<?php echo $locker_id; ?>" class="btn btn-danger">Delete</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php $x++;} ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include 'includecode/copyright.php'?>
            <!-- End of Footer -->
            
        </div>
        <!-- End of Content Wrapper -->

        

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>


    <!-- Foot -->
    <?php include 'includecode/foot.php' ?>
    <!-- Foot -->


</body>
</html>