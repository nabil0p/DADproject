<?php


// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Include the database connection file
    include_once('../db/db_connection.php');

    // Check if lockerKey and lockerLocationId are set in the POST request
    if (isset($_POST['lockerKey']) && isset($_POST['lockerLocationId'])) {
        $qrcodeRecipientId = $_POST['qrCode'];
        $lockerLocationId = $_POST['lockerLocationId'];
        $itemMngtId = $_POST['itemMngtId'];
        $lockerKey = $_POST['lockerKey'];
        $userUse = "Recipient";

        $resetQrPass = null;
        $lockerAvailabilityId = 2;
        $lockerStatusId = 1;

        // Prepare and bind parameters for updating locker
        $stmt = $conn->prepare("UPDATE locker SET qrCodePass = ?, locker_availability_id = ?, locker_status_id = ? , user_use = ? WHERE locker_id = ? AND locker_location_id = ?");
        $stmt->bind_param("siisss", $resetQrPass, $lockerAvailabilityId, $lockerStatusId, $userUse, $lockerKey, $lockerLocationId);

        if ($stmt->execute()) {

            // Set the default timezone to Kuala Lumpur
            date_default_timezone_set('Asia/Kuala_Lumpur');
            // Create a new DateTime object for the current date and time
            $date = new DateTime();
            // Format the date like SQL DATETIME
            $formattedDate = $date->format('Y-m-d H:i:s');
            $pickupDateUp = $formattedDate;

            $itemMngtStatusId = 3;
            $stmt1 = $conn->prepare("UPDATE item_management SET item_mngt_status_id = ?, pickup_date = ? WHERE item_mngt_id = ?");
            $stmt1->bind_param("iss", $itemMngtStatusId, $pickupDateUp, $itemMngtId);

            if ($stmt1->execute()) {
                $deliveryStatus = "1";
                $stmt2 = $conn->prepare("UPDATE qrcode_recipient SET status = ? WHERE qrcode_recipient_id = ?");
                $stmt2->bind_param("ss", $deliveryStatus, $qrcodeRecipientId);

                if ($stmt2->execute()) {
                    echo json_encode(['data' => 'Success', 'lockerId' => $lockerKey]);
                } else {
                    echo json_encode(['data' => 'Failed to update qrcode_recipient']);
                }
                $stmt2->close();
            } else {
                echo json_encode(['data' => 'Failed to update item_management']);
            }
            $stmt1->close();
        } else {
            echo json_encode(['data' => 'Failed to execute query']);
        }
        $stmt->close();
    } else {
        echo json_encode(['data' => 'lockerKey or lockerLocationId parameter is missing']);
    }

    $conn->close();

}
?>