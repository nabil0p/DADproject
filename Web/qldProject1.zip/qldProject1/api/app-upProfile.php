<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Include the database connection file
    include_once('../db/db_connection.php');
    
    // Get form data
    $username = $_POST['username'];
    $fullName = $_POST['full_name'];
    $emailAddress = $_POST['email_address'];
    $phoneNumber = $_POST['phone_number'];
    $icNumber = $_POST['ic_number'];
    
    // Check if the username exists in the database
    $sql = "SELECT * FROM users WHERE username = '$username'";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) == 0) {
        // Username does not exist, handle accordingly (e.g., return error message)
        echo json_encode("ErrorUsername");
        exit();
    }
    
    // Update user profile data in the database
    $sql = "UPDATE users SET full_name = '$fullName', mail_address = '$emailAddress', phone_num = '$phoneNumber', ic_num = '$icNumber' WHERE username = '$username'";
    
    if (mysqli_query($conn, $sql)) {
        // Data updated successfully
        echo json_encode("Success");
    } else {
        // Failed to update data
        echo json_encode("Error");
    }

    // Close database connection
    mysqli_close($conn);
} else {
    header("Location: ../404.php");
    exit();
}
?>