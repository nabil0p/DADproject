<?php

// Enable error reporting for debugging purposes
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    include_once('../db/db_connection.php');
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $fullName = $_POST['fullName'];
    $emailAddress = $_POST['emailAddress'];
    $icNumber = $_POST['icNumber'];
    $phoneNumber = $_POST['phoneNumber'];
    $roleId = 3;
    $availability = 1;

    // Log the received input
    error_log("Received input: username=$username, password=$password, fullName=$fullName, emailAddress=$emailAddress, icNumber=$icNumber, phoneNumber=$phoneNumber");

    // Check for duplicate email
    $query = "SELECT * FROM users WHERE mail_address = ?";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        echo json_encode("Prepare failed: " . $conn->error);
        exit();
    }
    $stmt->bind_param("s", $emailAddress);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        echo json_encode("ErrorEmail");
        exit();
    }

    // Check for duplicate username
    $query = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        echo json_encode("Prepare failed: " . $conn->error);
        exit();
    }
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        echo json_encode("ErrorUsername");
        exit();
    }

    // Check for duplicate phone number
    $query = "SELECT * FROM users WHERE phone_num = ?";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        echo json_encode("Prepare failed: " . $conn->error);
        exit();
    }
    $stmt->bind_param("s", $phoneNumber);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        echo json_encode("ErrorPhoneNumber");
        exit();
    }

    // Fetch the current maximum value of qld_id for the given role_id
    $query = "SELECT MAX(CAST(SUBSTRING(qld_id, 2) AS UNSIGNED)) AS max_id FROM users WHERE role_id = ?";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        echo json_encode("Prepare failed: " . $conn->error);
        exit();
    }
    $stmt->bind_param("i", $roleId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $row = $result->fetch_assoc()) {
        $maxId = $row['max_id'];
        $nextId = $maxId + 1;
        $qld_id = 'R' . str_pad($nextId, 4, '0', STR_PAD_LEFT);
    } else {
        $qld_id = 'R0001';
    }

    // Log the generated qld_id
    error_log("Generated qld_id: $qld_id");

    // Insert the new user
    $query = "INSERT INTO users (qld_id, username, password, full_name, mail_address, phone_num, ic_num, image, role_id, availability) 
              VALUES (?, ?, ?, ?, ?, ?, ?, NULL, ?, ?)";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        echo json_encode("Prepare failed: " . $conn->error);
        exit();
    }
    $stmt->bind_param("sssssssii", $qld_id, $username, $password, $fullName, $emailAddress, $phoneNumber, $icNumber, $roleId, $availability);

    if ($stmt->execute()) {
        echo json_encode("Success");
    } else {
        echo json_encode("Error: " . $stmt->error);
    }
} else {
    header("Location: ../404.php");
    exit();
}
?>
