<?php
include_once('../db/db_connection.php');

// Initialize output buffer
ob_start();

// Retrieve qldID from query parameter
if (isset($_GET['qldId']) && !empty($_GET['qldId'])) {
    $qldID = $_GET['qldId'];
    $roleId = $_GET['roleId'];

    if($roleId === "2"){
        $status = "1";
        // SQL query to fetch the required data
        $sql = "SELECT 
                    im.item_mngt_id,
                    im.arrived_date,
                    i.item_from,
                    ll.location_name
                FROM 
                    item_management im
                JOIN 
                    item i ON im.item_id = i.item_id
                JOIN 
                    locker_location ll ON i.locker_location_id = ll.locker_location_id
                JOIN 
                    qrcode_delivery qr ON im.qrcode_delivery_id = qr.qrcode_delivery_id 
                WHERE 
                    qr.courier_id = ? AND qr.status = ? LIMIT 10";

        // Prepare and execute the SQL statement
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $qldID, $status);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if there are results
        if ($result->num_rows > 0) {
            $data = array();
            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
            echo json_encode($data, JSON_UNESCAPED_UNICODE);
        } else {
            echo json_encode("0 results");
        }

        // Close statement
        $stmt->close();
    } 

    if($roleId === "3"){
        $status = 3;
        // SQL query to fetch the required data
        $sql = "SELECT 
                    im.item_mngt_id,
                    im.pickup_date,
                    i.item_from,
                    ll.location_name
                FROM 
                    item_management im
                JOIN 
                    item i ON im.item_id = i.item_id
                JOIN 
                    locker_location ll ON i.locker_location_id = ll.locker_location_id
                JOIN 
                    qrcode_recipient qr ON im.qrcode_recipient_id = qr.qrcode_recipient_id 
                WHERE 
                    qr.recipient_id = ? AND im.item_mngt_status_id = ? LIMIT 10";

        // Prepare and execute the SQL statement
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $qldID, $status);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if there are results
        if ($result->num_rows > 0) {
            $data = array();
            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
            echo json_encode($data, JSON_UNESCAPED_UNICODE);
        } else {
            echo json_encode("0 results");
        }

        // Close statement
        $stmt->close();
    } 
} else {
    echo json_encode("Invalid or missing qldID");
    header("Location: ../404.php");
}

// Close connection
$conn->close();

// Flush output buffer
ob_end_flush();
?>
