<?php


// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Include the database connection file
    include_once('../db/db_connection.php');
        
        // Get the username and image file
        $username = $_POST['username'];
        $image = $_FILES['image'];

        // Check if the image upload was successful
        if ($image['error'] === UPLOAD_ERR_OK) {

            

            $image = file_get_contents($_FILES["image"]["tmp_name"]);
            $updateImageQuery = "UPDATE users SET image = ? WHERE username = ?";
            
            $stmt = $conn->prepare($updateImageQuery);
            $stmt->bind_param("ss", $image, $username);
            $stmt->send_long_data(0, $image);
            $stmt->execute();

            // Execute the update query
            if ($stmt->execute()) {
                // Image updated successfully
                echo json_encode("Success");
            } else {
                // Failed to update image
                echo json_encode("Error: Failed to update image");
            }
            
        } else {
            // Image upload failed
            echo json_encode("Error: Image upload failed");
        }
        
    } else {
        header("Location: ../404.php");
        exit();
    }

?>