<?php
// Function to log errors
function log_error($message) {
    error_log($message);
}

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include the database connection file
    include_once('../db/db_connection.php');

    // Check if the required parameters are set in the POST request
    if (isset($_POST['lockerId']) && isset($_POST['roleId']) && isset($_POST['lockerLocationId'])) {
        $lockerId = $_POST['lockerId'];
        $roleId = $_POST['roleId'];
        $lockerLocationId = $_POST['lockerLocationId'];

        // Ensure the foreign key constraints are satisfied
        $stmt_check = $conn->prepare("SELECT COUNT(*) FROM locker WHERE locker_id = ? AND locker_location_id = ?");
        $stmt_check->bind_param("ss", $lockerId, $lockerLocationId);
        $stmt_check->execute();
        $stmt_check->bind_result($count);
        $stmt_check->fetch();
        $stmt_check->close();

        if ($count == 0) {
            echo json_encode([
                'data' => 'Invalid lockerId or lockerLocationId',
                'received' => [
                    'lockerId' => $lockerId,
                    'roleId' => $roleId,
                    'lockerLocationId' => $lockerLocationId
                ]
            ]);
            exit();
        }

        if ($roleId == "2") {
            $lockerAvailabilityId = 1;
            $lockerStatusId = 2;
            $userUse = "Nobody";

            // Prepare and bind parameters
            $stmt = $conn->prepare("UPDATE locker SET locker_availability_id = ?, locker_status_id = ?, user_use = ? WHERE locker_id = ? AND locker_location_id = ?");
            $stmt->bind_param("iisss", $lockerAvailabilityId, $lockerStatusId, $userUse, $lockerId, $lockerLocationId);

            // Execute the statement
            if ($stmt->execute()) {
                echo json_encode(['data' => 'Success']);
            } else {
                log_error("Failed to execute query: " . $stmt->error);
                echo json_encode(['data' => 'Failed to execute query']);
            }

            // Close the statement
            $stmt->close();
        } elseif ($roleId == "3") {
            $lockerAvailabilityId = 2;
            $lockerStatusId = 2;
            $userUse = "Nobody";

            // Prepare and bind parameters
            $stmt = $conn->prepare("UPDATE locker SET locker_availability_id = ?, locker_status_id = ?, user_use = ? WHERE locker_id = ? AND locker_location_id = ?");
            $stmt->bind_param("iisss", $lockerAvailabilityId, $lockerStatusId, $userUse, $lockerId, $lockerLocationId);

            // Execute the statement
            if ($stmt->execute()) {
                echo json_encode(['data' => 'Success', 'lockerId' => $lockerId]);
            } else {
                log_error("Failed to execute query: " . $stmt->error);
                echo json_encode(['data' => 'Failed to execute query']);
            }

            // Close the statement
            $stmt->close();
        } else {
            echo json_encode(['data' => 'Invalid roleId']);
        }
    } else {
        // Missing parameters
        echo json_encode(['data' => 'Required parameters are missing']);
    }

    // Close the connection
    $conn->close();
}
?>
