<?php
// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Include the database connection file
    include_once('../db/db_connection.php');

    // Check if qrRecipient and lockerLocationId are set in the POST request
    if (isset($_POST['qrRecipient']) && isset($_POST['lockerLocationId'])) {
        $qrRecipient = $_POST['qrRecipient'];
        $lockerLocationId = $_POST['lockerLocationId'];
        $itemMngtId = $_POST['itemMngtId'];
        $qrcodeDeliveryId = $_POST['qrCode'];
        $lockerId = $_POST['lockerId']; //additional
        $userUse = "Courier";

        // Prepare the SQL statement
        $stmt30 = $conn->prepare("SELECT recipient_id FROM qrcode_recipient WHERE qrcode_recipient_id = ?");
        $stmt30->bind_param("s", $qrRecipient); // "s" denotes the type of the parameter (string)

        // Execute the query
        $stmt30->execute();

        // Get the result
        $result30 = $stmt30->get_result();

        // Check if there are results
        if ($result30->num_rows > 0) {
            // Output data of each row
            while($row = $result30->fetch_assoc()) {
                $recipientId = $row["recipient_id"];
            }
        } else {
            echo json_encode(['data' => 'No Recipient ID']);
        }

        // Close the statement and connection
        $stmt30->close();

        // Check if the locker is already open
        $sql1 = "SELECT locker_id 
                 FROM locker 
                 WHERE locker_status_id = 1 AND locker_availability_id = 1 AND locker_location_id = ? AND qrCodePass = ?
                 ORDER BY locker_id ASC LIMIT 1;";

        $stmt1 = $conn->prepare($sql1);
        $stmt1->bind_param("ss", $lockerLocationId, $qrRecipient);
        $stmt1->execute();
        $result1 = $stmt1->get_result();

        if ($result1->num_rows > 0) {
            $row1 = $result1->fetch_assoc();
            $oldLockerId = $row1["locker_id"];
            echo json_encode(['data' => 'Locker is Already Open', 'lockerId' => $oldLockerId]);
            $conn->close();
            exit;
        }

        // Check if the locker can be reopened
        $sql2 = "SELECT locker_id 
                 FROM locker 
                 WHERE locker_status_id = 2 AND locker_location_id = ? AND qrCodePass = ?
                 ORDER BY locker_id ASC LIMIT 1;";

        $stmt2 = $conn->prepare($sql2);
        $stmt2->bind_param("ss", $lockerLocationId, $qrRecipient);
        $stmt2->execute();
        $result2 = $stmt2->get_result();

        if ($result2->num_rows > 0) {
            $row2 = $result2->fetch_assoc();
            $oldLockerId = $row2["locker_id"];

            $lockerAvailabilityId = 1;
            $lockerStatusId = 1;

            // Prepare and bind parameters for reopening the locker
            $stmt3 = $conn->prepare("UPDATE locker SET qrCodePass = ?, locker_availability_id = ?, locker_status_id = ? WHERE locker_id = ? AND locker_location_id = ?");
            $stmt3->bind_param("siiss", $qrRecipient, $lockerAvailabilityId, $lockerStatusId, $oldLockerId, $lockerLocationId);

            if ($stmt3->execute()) {
                echo json_encode(['data' => 'Opening The Locker Again', 'lockerId' => $oldLockerId]);
            } else {
                echo json_encode(['data' => 'Failed to execute query']);
            }

            $conn->close();
            exit;
        }

        // // Find an available locker
        // $sql3 = "SELECT locker_id 
        //          FROM locker 
        //          WHERE locker_availability_id = 2 AND locker_location_id = ?
        //          ORDER BY locker_id ASC LIMIT 1;";

        // $stmt4 = $conn->prepare($sql3);
        // $stmt4->bind_param("s", $lockerLocationId);
        // $stmt4->execute();
        // $result3 = $stmt4->get_result();

        // if ($result3->num_rows > 0) {
        //     $row = $result3->fetch_assoc();
        //     $lockerId = $row["locker_id"];
        // } else {
        //     echo json_encode(['data' => 'All Locker Is Full']);
        //     $conn->close();
        //     exit;
        // }

        // Prepare and bind parameters for updating the locker
        $lockerAvailabilityId = 1;
        $lockerStatusId = 1;
        $stmt5 = $conn->prepare("UPDATE locker SET qrCodePass = ?, locker_availability_id = ?, locker_status_id = ?, user_use = ? WHERE locker_id = ? AND locker_location_id = ?");
        $stmt5->bind_param("siisss", $qrRecipient, $lockerAvailabilityId, $lockerStatusId, $userUse, $lockerId, $lockerLocationId);

        // Execute the statement
        if ($stmt5->execute()) {
            // Update item_management status
            $itemMngtStatusId = 2;
            // Set the default timezone to Kuala Lumpur
            date_default_timezone_set('Asia/Kuala_Lumpur');
            // Create a new DateTime object for the current date and time
            $date = new DateTime();
            // Format the date like SQL DATETIME
            $formattedDate = $date->format('Y-m-d H:i:s');
            $arrivedDateUp = $formattedDate;

            // Prepare the SQL statement
            $stmt6 = $conn->prepare("UPDATE item_management SET item_mngt_status_id = ?, arrived_date = ? WHERE item_mngt_id = ?");
            $stmt6->bind_param("iss", $itemMngtStatusId, $arrivedDateUp, $itemMngtId);

            if ($stmt6->execute()) {
                // Update qrcode_delivery status
                $deliveryStatus = "1";
                $stmt7 = $conn->prepare("UPDATE qrcode_delivery SET status = ?, locker_id = ? WHERE qrcode_delivery_id = ?");
                $stmt7->bind_param("sss", $deliveryStatus, $lockerId, $qrcodeDeliveryId);

                if ($stmt7->execute()) {
                    // Update qrcode_recipient table
                    $stmt8 = $conn->prepare("UPDATE qrcode_recipient SET locker_id = ? WHERE qrcode_recipient_id = ?");
                    $stmt8->bind_param("ss", $lockerId, $qrRecipient);

                    if ($stmt8->execute()) {
                        // Prepare the SQL statement to get the item_id from the item_management table
                        $stmt9 = $conn->prepare("SELECT item_id FROM item_management WHERE item_mngt_id = ?");
                        $stmt9->bind_param("s", $itemMngtId);
                        $stmt9->execute();
                        $result4 = $stmt9->get_result();
                        $data = $result4->fetch_assoc();
                        $itemId = $data['item_id'];

                        // Prepare the SQL statement to update the locker_id in the item table
                        $stmt10 = $conn->prepare("UPDATE item SET locker_id = ? WHERE item_id = ?");
                        $stmt10->bind_param("ss", $lockerId, $itemId);

                        if ($stmt10->execute()) {
                            // Send push notification using OneSignal
                            $api_url = 'https://onesignal.com/api/v1/notifications';
                            $app_id = '5873f180-bc70-4eef-aec0-2337ca6c04bd';
                            $api_key = 'ZTdmYjVmYzQtOTJlZC00NDMzLWExMjgtZWU1OTQwNjdhYTll';

                            $contents = array('en' => "Hello, {$recipientId}! You have item(s) arrived. Please check your arrived list.");

                            $data = array(
                                'app_id' => $app_id,
                                'include_external_user_ids' => array($recipientId), // This should be an array
                                'contents' => $contents,
                            );

                            // Convert data to JSON
                            $data_string = json_encode($data);

                            // Set up cURL for making the request
                            $ch = curl_init($api_url);
                            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                                'Content-Type: application/json',
                                'Authorization: Basic ' . $api_key,
                            ));
                            curl_setopt($ch, CURLOPT_POST, 1);
                            curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                            // Execute cURL request
                            $result = curl_exec($ch);

                            // Check for cURL errors
                            if (curl_errno($ch)) {
                                echo 'Curl error: ' . curl_error($ch);
                                // Handle the error as needed
                                exit();
                            } else {
                                // Close cURL session
                                curl_close($ch);
                            }

                            // Check if the notification was sent successfully
                            $responseData = json_decode($result, true);

                            if (isset($responseData['id'])) {
                            echo json_encode(['data' => 'Success', 'lockerId' => $lockerId]);
                            }
                            
                            
                        } else {
                            echo json_encode(['data' => 'Failed to update item']);
                        }

                        $stmt10->close();
                        $stmt9->close();
                    } else {
                        echo json_encode(['data' => 'Failed to update qrcode_recipient']);
                    }

                    $stmt8->close();
                } else {
                    echo json_encode(['data' => 'Failed to update qrcode_delivery']);
                }

                $stmt7->close();
            } else {
                echo json_encode(['data' => 'Failed to update item_management']);
            }

            $stmt6->close();
        } else {
            echo json_encode(['data' => 'Failed to execute query']);
        }

        $stmt5->close();
    } else {
        echo json_encode(['data' => 'qrRecipient or lockerLocationId parameter is missing']);
    }

    $conn->close();
} else {
    echo json_encode(['data' => 'Invalid request method']);
}
?>
