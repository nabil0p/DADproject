<?php

if (!isset($_SESSION["id"])) {
    header("Location: ../index.php");
    exit;
}

$user_id = $_SESSION["id"];

include '../db/db_connection.php'; // Include your database connection

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $locationid = $_POST["location"];
    $lockerid = $_POST["qldid"];
}

?>