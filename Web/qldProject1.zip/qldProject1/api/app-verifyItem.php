<?php
// Check if the request method is GET
if ($_SERVER["REQUEST_METHOD"] == "GET") {

    // Include the database connection file
    include_once('../db/db_connection.php');

    $qrCode = $_GET['qrCode'];
    $itemMngtId = $_GET['itemMngtId'];
    $roleId = $_GET['roleId'];
    $lockerLocationId = $_GET['lockerLocationId'];
    $itemSize = $_GET['itemSize'];


    if ($roleId === "2") {
        // Prepare the statement to find an available locker
        $stmt1 = $conn->prepare("SELECT locker_id FROM locker WHERE locker_location_id = ? AND locker_availability_id = ? AND locker_status_id = ? AND locker_size = ?");
        $lockerAvailabilityId = 2;
        $lockerStatusId = 2;
        $stmt1->bind_param("siis", $lockerLocationId, $lockerAvailabilityId, $lockerStatusId, $itemSize);

        // Execute the statement and get the result
        $stmt1->execute();
        $result1 = $stmt1->get_result();

        // Check if the query returned any rows
        if ($result1->num_rows > 0) {
            // Fetch the result as an associative array
            $row1 = $result1->fetch_assoc();
        } else {
            echo json_encode(['data' => 'No Locker Available']);
            exit();
        }

        $statusMngtId = 1;

        // Prepare and bind statement to check QR code and item management ID
        $stmt = $conn->prepare("SELECT qrcode_recipient_id FROM item_management WHERE qrcode_delivery_id = ? AND item_mngt_id = ? AND item_mngt_status_id = ?");
        $stmt->bind_param("ssi", $qrCode, $itemMngtId, $statusMngtId);

        // Execute the statement and get the result
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if the QR code, item management ID, and status exist
        if ($result->num_rows > 0) {
            // Fetch the result as an associative array
            $row = $result->fetch_assoc();
            echo json_encode(['data' => 'Success', 'locker_key' => $row['qrcode_recipient_id']]);
        } else {
            echo json_encode(['data' => 'Failed']);
        }
        
        $stmt1->close();
    }

    if ($roleId === "3") {
        // Prepare the SQL statement
        $stmt30 = $conn->prepare("SELECT recipient_id FROM qrcode_recipient WHERE qrcode_recipient_id = ?");
        $stmt30->bind_param("s", $qrCode); // "s" denotes the type of the parameter (string)

        // Execute the query
        $stmt30->execute();

        // Get the result
        $result30 = $stmt30->get_result();

        // Check if there are results
        if ($result30->num_rows > 0) {
            // Output data of each row
            while($row = $result30->fetch_assoc()) {
                $recipientId = $row["recipient_id"];
            }
        } else {
            echo json_encode(['data' => 'No Recipient ID']);
        }

        // Prepare and bind statement to check locker by QR code and location
        $stmt = $conn->prepare("SELECT locker_id FROM locker WHERE qrCodePass = ? AND locker_location_id = ?");
        $stmt->bind_param("ss", $qrCode, $lockerLocationId);

        // Execute the statement and get the result
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if the locker associated with the QR code exists
        if ($result->num_rows > 0) {
            // Fetch the result as an associative array
            $row = $result->fetch_assoc();
            // Send push notification using OneSignal
            $api_url = 'https://onesignal.com/api/v1/notifications';
            $app_id = '5873f180-bc70-4eef-aec0-2337ca6c04bd';
            $api_key = 'ZTdmYjVmYzQtOTJlZC00NDMzLWExMjgtZWU1OTQwNjdhYTll';

            $contents = array('en' => "Hello, {$recipientId}! Don't forget to close the locker!");

            $data = array(
                'app_id' => $app_id,
                'include_external_user_ids' => array($recipientId), // This should be an array
                'contents' => $contents,
            );

            // Convert data to JSON
            $data_string = json_encode($data);

            // Set up cURL for making the request
            $ch = curl_init($api_url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'Authorization: Basic ' . $api_key,
            ));
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            // Execute cURL request
            $result = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                echo 'Curl error: ' . curl_error($ch);
                // Handle the error as needed
                exit();
            } else {
                // Close cURL session
                curl_close($ch);
            }

            // Check if the notification was sent successfully
            $responseData = json_decode($result, true);

            if (isset($responseData['id'])) {
                echo json_encode(['data' => 'Success', 'locker_key' => $row['locker_id']]);
            }


        } else {
            echo json_encode(['data' => 'Failed']);
        }
        
        $stmt->close();
    }

    // Close the statement and the connection
    $conn->close();
}
?>
