<?php
include_once('../db/db_connection.php');

// Receive updated password data from the request
$userId = $_POST['user_id'];
$oldPassword = $_POST['oldPassword'];
$newPassword = $_POST['newPassword'];

// Check if the submitted old password matches the existing hashed password
$sqlCheck = "SELECT * FROM users WHERE username = ?";
$stmtCheck = $conn->prepare($sqlCheck);
$stmtCheck->bind_param("s", $userId);
$stmtCheck->execute();
$resultCheck = $stmtCheck->get_result();

$response = array(); // Create an associative array for the response

if ($resultCheck->num_rows > 0) {
    $row = $resultCheck->fetch_assoc();
    $hashedPassword = $row['password'];

    // Verify the old password
    if (password_verify($oldPassword, $hashedPassword)) {
        // Old password matches, hash the new password
        $hashedNewPassword = password_hash($newPassword, PASSWORD_DEFAULT);

        // Update the user's password in the database
        $sqlUpdate = "UPDATE users SET password = ? WHERE username = ?";
        $stmtUpdate = $conn->prepare($sqlUpdate);
        $stmtUpdate->bind_param("ss", $hashedNewPassword, $userId);

        if ($stmtUpdate->execute()) {
            $response['success'] = true;
            $response['message'] = "Password updated successfully";
        } else {
            $response['success'] = false;
            $response['message'] = "Error updating password: " . $conn->error;
        }
        $stmtUpdate->close();
    } else {
        $response['success'] = false;
        $response['message'] = "Old password is incorrect";
    }
} else {
    $response['success'] = false;
    $response['message'] = "User not found";
}

$stmtCheck->close();
$conn->close();

// Return the response as JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
