<?php


// Get the item management ID from the query parameters
$itemMngtId = $_GET['itemMngtId'] ?? '';

if (empty($itemMngtId)) {
    echo json_encode(array("error" => "No item management ID provided"));
    exit();
}

include_once('../db/db_connection.php');

// SQL query to fetch item details
$sql = " SELECT 
            im.item_mngt_id,
            im.pic_id,
            im.item_id,
            im.item_mngt_status_id,
            ims.status_name,
            im.register_date,
            im.arrived_date,
            im.pickup_date,
            im.qrcode_recipient_id,
            im.qrcode_delivery_id,
            im.availability,
            i.item_from,
            i.locker_location_id,
            i.locker_id,
            i.item_size_id,
            iz.size_type,
            ll.location_name,
            ll.location_address,
            qr.recipient_id
        FROM 
            item_management im
        LEFT JOIN  
            item i ON im.item_id = i.item_id
        LEFT JOIN  
            item_size iz ON i.item_size_id = iz.item_size_id
        LEFT JOIN  
            item_management_status ims ON im.item_mngt_status_id = ims.item_mngt_status_id
        LEFT JOIN 
            locker_location ll ON i.locker_location_id = ll.locker_location_id
        LEFT JOIN 
            qrcode_recipient qr ON im.qrcode_recipient_id = qr.qrcode_recipient_id
        WHERE 
            im.item_mngt_id = ?;
        ";

// Prepare and bind
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $itemMngtId);

// Execute the query
$stmt->execute();
$result = $stmt->get_result();

// Check if the item management ID exists
if ($result->num_rows > 0) {
    $itemDetails = $result->fetch_assoc();
    echo json_encode($itemDetails);
} else {
    echo json_encode(array("error" => "Item management ID not found"));
}

// Close connections
$stmt->close();
$conn->close();
?>