<?php
// Function to log errors
function log_error($message) {
    error_log($message);
}

// Check if the request method is POST
// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include the database connection file
    include_once('../db/db_connection.php');

    // Check if the required parameters are set in the POST request
    if (isset($_POST['qldId']) && isset($_POST['available'])) {
        $qldId = $_POST['qldId'];
        $available = $_POST['available'];

        // Determine the availabilityId based on the available parameter
        if ($available == "1") {
            $availabilityId = "0";
        } elseif ($available == "0") {
            $availabilityId = "1";
        } else {
            echo json_encode(['data' => 'Invalid availability value']);
            exit;
        }

        // Prepare and bind parameters
        $stmt = $conn->prepare("UPDATE courier_details SET availability_id = ? WHERE courier_id = ?");
        $stmt->bind_param("ss", $availabilityId, $qldId);

        // Execute the statement
        if ($stmt->execute()) {
            echo json_encode(['data' => 'Success', 'availability' => $availabilityId]);
        } else {
            log_error("Failed to execute query: " . $stmt->error);
            echo json_encode(['data' => 'Failed to execute query']);
        }

        // Close the statement
        $stmt->close();
    } else {
        // Missing parameters
        echo json_encode(['data' => 'Required parameters are missing']);
    }

    // Close the connection
    $conn->close();
}