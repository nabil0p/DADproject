<?php

if (isset($_GET['qldId']) && !empty($_GET['qldId']) && isset($_GET['roleId']) && !empty($_GET['roleId'])) {
    $qldID = $_GET['qldId'];
    $roleId = $_GET['roleId'];

    include_once('../db/db_connection.php');

    header('Content-Type: application/json');

    // Open an output buffer
    ob_start();

    if ($roleId === "2") {
        // SQL query to fetch the required data
        $sql1 = "SELECT COUNT(courier_id) As cPendingCount FROM qrcode_delivery WHERE courier_id = ? AND status = '0'";
        $sql2 = "SELECT COUNT(courier_id) As cDeliveredCount FROM qrcode_delivery WHERE courier_id = ? AND status = '1'";
        $sql3 = "SELECT availability_id As cAvailable FROM courier_details WHERE courier_id = ?";

        // Prepare and execute the SQL statements
        $stmt1 = $conn->prepare($sql1);
        $stmt1->bind_param("s", $qldID);
        $stmt1->execute();
        $result1 = $stmt1->get_result();

        $stmt2 = $conn->prepare($sql2);
        $stmt2->bind_param("s", $qldID);
        $stmt2->execute();
        $result2 = $stmt2->get_result();

        $stmt3 = $conn->prepare($sql3);
        $stmt3->bind_param("s", $qldID);
        $stmt3->execute();
        $result3 = $stmt3->get_result();

        // Fetch the results
        $cPendingCount = $result1->fetch_assoc()['cPendingCount'] ?? 0;
        $cDeliveredCount = $result2->fetch_assoc()['cDeliveredCount'] ?? 0;
        $cAvailable = $result3->fetch_assoc()['cAvailable'] ?? "0";

        // Prepare the response data
        $data = array(
            'cPending' => array('cPendingCount' => $cPendingCount),
            'cDelivered' => array('cDeliveredCount' => $cDeliveredCount),
            'cAvailable' => array('cAvailable' => $cAvailable),
        );

        echo json_encode($data);

        // Close statements
        $stmt1->close();
        $stmt2->close();
        $stmt3->close();
    } 

    if ($roleId === "3") {
        // SQL query to fetch the required data
        $sql1 = "SELECT COUNT(qr.recipient_id) As rArrivedCount FROM item_management im JOIN qrcode_recipient qr ON im.qrcode_recipient_id = qr.qrcode_recipient_id WHERE qr.recipient_id = ? AND im.item_mngt_status_id = 2;";
        $sql2 = "SELECT COUNT(qr.recipient_id) As rPickedCount FROM item_management im JOIN qrcode_recipient qr ON im.qrcode_recipient_id = qr.qrcode_recipient_id WHERE qr.recipient_id = ? AND im.item_mngt_status_id = 3;";

        // Prepare and execute the SQL statement
        $stmt1 = $conn->prepare($sql1);
        $stmt1->bind_param("s", $qldID);
        $stmt1->execute();
        $result1 = $stmt1->get_result();

        $stmt2 = $conn->prepare($sql2);
        $stmt2->bind_param("s", $qldID);
        $stmt2->execute();
        $result2 = $stmt2->get_result();

        // Check if there are results
        if ($result1->num_rows > 0 && $result2->num_rows > 0) {
            $data = array();
            $data['rArrivedCount'] = $result1->fetch_assoc();
            $data['rPickedCount'] = $result2->fetch_assoc();
            echo json_encode($data);
        } else {
            echo json_encode("0 results");
        }

        // Close statements
        $stmt1->close();
        $stmt2->close();
    } 
} else {
    echo json_encode("Invalid or missing qldID or roleId");
    //header("Location: ../404.php");
}

// Flush the output buffer
ob_end_flush();

// Close connection
$conn->close();
?>
