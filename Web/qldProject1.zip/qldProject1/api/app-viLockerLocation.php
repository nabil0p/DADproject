<?php

include_once('../db/db_connection.php');

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

// Open an output buffer
ob_start();

// Start output buffering and begin JSON output
echo '[';

$sql = "SELECT locker_location_id, location_name, location_address, location_image FROM locker_location";
$result = $conn->query($sql);

$firstRow = true;

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if (!$firstRow) {
            echo ','; // Add comma between JSON objects
        }
        $row['location_image'] = base64_encode($row['location_image']); // Convert image blob to base64
        echo json_encode($row);
        $firstRow = false;
    }
}

echo ']';

// Flush the output buffer
ob_end_flush();

$conn->close();
?>
