<?php
// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Include the database connection file
    include_once('../db/db_connection.php');

    // Check if qrRecipient and lockerLocationId are set in the POST request
    if (isset($_POST['lockerLocationId']) && isset($_POST['itemSize'])) {
        $lockerLocationId = $_POST['lockerLocationId'];
        $itemSize = $_POST['itemSize'];

        // Find an available locker
        $sql3 = "SELECT locker_id 
                 FROM locker 
                 WHERE locker_availability_id = 2 AND locker_location_id = ? AND locker_size = ?
                 ORDER BY locker_id ASC LIMIT 1;";

        $stmt4 = $conn->prepare($sql3);
        $stmt4->bind_param("ss", $lockerLocationId, $itemSize);
        $stmt4->execute();
        $result3 = $stmt4->get_result();

        if ($result3->num_rows > 0) {
            $row = $result3->fetch_assoc();
            $lockerId = $row["locker_id"];

            echo json_encode(['data' => 'Success', 'lockerId' => $lockerId]);
        } else {
            echo json_encode(['data' => 'All Locker Is Full']);
            $conn->close();
            exit;
        }
    } else {
        echo json_encode(['data' => 'qrRecipient or lockerLocationId parameter is missing']);
    }

    $conn->close();
} else {
    echo json_encode(['data' => 'Invalid request method']);
}
?>
