<?php

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Include the database connection file
    include_once('../db/db_connection.php');

$username = $_POST['username'];
$password = $_POST['password'];

// Prepare and execute the SQL query to find the user by username
$sql = "SELECT * FROM users WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$count = $result->num_rows;

if ($count == 1) {
    // Retrieve the user information from the query result
    $row = $result->fetch_assoc();

    // Get the hashed password from the database
    $storedHashedPassword = $row['password'];

    // Verify the entered password against the stored hash
    if (password_verify($password, $storedHashedPassword)) {
        // Password is correct

        // Fetch other user information as needed
        $qld_id = $row['qld_id'];
        $username = $row['username'];
        $icNumber = $row['ic_num'];
        $fullName = $row['full_name'];
        $phoneNumber = $row['phone_num'];
        $emailAddress = $row['mail_address'];
        $image = base64_encode($row['image']);
        $role_id = $row['role_id'];

        // Prepare and execute the SQL query to find the role by role_id
        $role_sql = "SELECT * FROM role WHERE role_id = ?";
        $role_stmt = $conn->prepare($role_sql);
        $role_stmt->bind_param("i", $role_id);
        $role_stmt->execute();
        $role_result = $role_stmt->get_result();
        $role_row = $role_result->fetch_assoc();
        $rolename = $role_row['role_name'];

        // Create a JSON response array
        $response = array(
            "status" => "Success",
            "qld_id" => $qld_id,
            "username" => $username,
            "icNumber" => $icNumber,
            "fullName" => $fullName,
            "phoneNumber" => $phoneNumber,
            "emailAddress" => $emailAddress,
            "image" => $image,
            "rolename" => $rolename,
            "role_id" => $role_id
        );

        // Encode the array as JSON and echo it
        echo json_encode($response);
    } else {
        // Password is incorrect
        echo json_encode(array("status" => "ErrorPass"));
    }
} else {
    // No user found with the given username
    echo json_encode(array("status" => "ErrorUsername"));
}
} else {
    // Redirect to 404 page if the request method is not POST
    
    header("Location: ../404.php");
    exit();
}


?>