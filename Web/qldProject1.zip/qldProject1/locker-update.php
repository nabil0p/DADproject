<?php
session_start();

// Check if user is logged in, redirect to login page if not
if (!isset($_SESSION["id"])) {
    header("Location: login.php");
    exit;
}
$page = 'locker-update.php'; 
$screen_name = 'Update Locker';


$locker_id = isset($_GET['locker_id']) ? $_GET['locker_id'] : '';

include 'db/db_connection.php'; // Include your database connection

// Ensure $location_id is not empty and is a valid integer
if (!empty($locker_id)) {
    $stmt = $conn->prepare("SELECT locker_name, locker_size, locker_location_id, locker_status_id, locker_availability_id, qrCodePass FROM locker WHERE locker_id = ?");
    $stmt->bind_param("s", $locker_id);
    $stmt->execute();
    $stmt->bind_result($locker_name, $locker_size, $locker_location_id, $locker_status_id, $locker_availability, $qrCodePass);

    // Fetch the results
    $stmt->fetch(); 
    $stmt->close();
} else {
    echo "Invalid or missing locker_location parameter.";
}


?>

<!DOCTYPE html>
<html>
<head>
    <!-- Head -->
    <?php include 'includecode/head.php' ?>
    <!-- Head -->
</head>
<style>
    <?php include 'includecode/plusdesign.php' ?>
</style>

    
<body id="page-top">
    <?php
        // Check if 'error' parameter is set in the URL
        if (isset($_GET['error'])) {
            // Display an error message with the value of the 'error' parameter
            echo '<div id="alert-containers" class="alert alert-danger" role="alert">' . $_GET['error'] . '</div>';
            
        }

        // Check if 'error' parameter is set in the URL
        if (isset($_GET['success'])) {
            // Display an error message with the value of the 'error' parameter
            echo '<div id="alert-containers" class="alert alert-success" role="success">' . $_GET['success'] . '</div>';
            
        }
    
    ?>

    <script>
        // Wait for the DOM to be ready
        document.addEventListener("DOMContentLoaded", function() {
            // Set a timeout to hide the error message after 5 seconds
            setTimeout(function() {
                var alertContainer = document.getElementById('alert-containers');
                if (alertContainer) {
                    // Hide the error message by setting display to 'none'
                    alertContainer.style.display = 'none';
                }
            }, 3000); // 3000 milliseconds = 3 seconds
        });
    </script>

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Side Nav -->
        <?php include 'function/navigation/sidenav.php' ?>
        <!-- Side Nav -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include 'function/navigation/topnav.php' ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">Update Locker</h1>
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Update Locker</h6>
                        </div>
                            <form method="post" action="function/update-locker.php?locker_id=<?php echo $locker_id?>" enctype="multipart/form-data" onsubmit="return validateForm()">                            
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label class="required" for="locker_id">Locker ID:</label>
                                            <input type="text" class="form-control" id="locker_id" name="locker_id" value="<?php echo htmlspecialchars($locker_id);?>" onkeyup="validatelockerid()" readonly>
                                            <span id="lockeridError" class="errorss"></span>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label class="required" for="locker_name">Locker Name:</label>
                                            <input type="text" class="form-control" id="locker_name" name="locker_name" value="<?php echo htmlspecialchars($locker_name);?>" onkeyup="validatelockername()">
                                            <span id="lockernameError" class="errorss"></span>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label class="required" for="locker_size">Locker Size:</label>
                                            <input type="text" class="form-control" id="locker_size" name="locker_size" value="<?php echo htmlspecialchars($locker_size);?>" onkeyup="validatelockersize()">
                                            <span id="lockersizeError" class="errorss"></span>
                                        </div>
                                    </div>
                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group">
                                                <label class="required" for="locker_location_id">Locker Location: </label>
                                                <select class="custom-select" id="locker_location_id" name="locker_location_id">
                                                    <?php
                                                        // Assuming $conn is your database connection
                                                        $query = "SELECT locker_location_id, location_name , location_address FROM locker_location WHERE availability = 1;";
                                                        $result = $conn->query($query);

                                                        if ($result && $result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $location_id = $row['locker_location_id'];
                                                                $address = $row['location_name'];
                                                                $selected = ($location_id == $locker_location_id) ? 'selected' : ''; // Check if this option is selected
                                                                echo "<option value='$location_id' $selected>$address</option>";
                                                            }
                                                        } else {
                                                            echo "<option value='' disabled>No locations available</option>";
                                                        }

                                                        // Close the result set
                                                        $result->close();
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group">
                                                <label class="required" for="locker_status_id">Locker Status:</label>
                                                <select class="custom-select" id="locker_status_id" name="locker_status_id" onchange="validatelockerstatusid()">
                                                    <option value="1" <?php if ($locker_status_id == 1) echo 'selected'; ?>>Open</option>
                                                    <option value="2" <?php if ($locker_status_id == 2) echo 'selected'; ?>>Close</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group">
                                                <label class="required" for="locker_availability">Availability:</label>
                                                <select class="custom-select" id="locker_availability" name="locker_availability" onchange="validatelocker_availability()">
                                                    <option value="1" <?php if ($locker_availability == 1) echo 'selected'; ?>>Has Item</option>
                                                    <option value="2" <?php if ($locker_availability == 2) echo 'selected'; ?>>Empty</option>
                                                </select>
                                            </div>
                                        </div>
                                </div>
                                
                                        <!-- <div class="col-xl-3 col-md-6">
                                                <div class="form-group">
                                                    <label for="qrCodePass">qrCodePass:</label>
                                                    <input type="text" class="form-control" id="qrCodePass" name="qrCodePass" value="<?php //echo htmlspecialchars($qrCodePass);?>" >
                                                    <span id="lockersizeError" class="errorss"></span>
                                                </div>
                                            </div> -->
                            </div>
                            <div class="card-footer py-3">
                                <div class="row">
                                    <div class="col-xl-6 col-md-6">
                                        <div class="small text-white">
                                            <a href="locker-list.php?location=" class="btn btn-primary btn-sm">Back</a>
                                        </div>
                                    </div>
                                    <div class="col-xl-6 col-md-6">
                                        <div style="float:right;">
                                            <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i>&nbsp;&nbsp;Update</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include 'includecode/copyright.php'?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Foot -->
    <?php include 'includecode/foot.php' ?>
    <!-- Foot -->

    <script>
        function validatelockerid() {
            var locker_id = document.getElementById('locker_id').value;
            var lockeridError = document.getElementById('lockeridError');
            if (locker_id.trim() === '') {
                lockeridError.innerHTML = 'Locker Id is required';
            } else {
                lockeridError.innerHTML = '';
            }
        }

        function validatelockername() {
            var locker_name = document.getElementById('locker_name').value;
            var lockernameError = document.getElementById('lockernameError');
            if (locker_name.trim() === '') {
                lockernameError.innerHTML = 'Locker Name is required';
            } else {
                lockernameError.innerHTML = '';
            }
        }

        function validatelockersize() {
            var locker_size = document.getElementById('locker_size').value;
            var lockersizeError = document.getElementById('lockersizeError');
            if (locker_size.trim() === '') {
                lockersizeError.innerHTML = 'Locker Name is required';
            } else {
                lockersizeError.innerHTML = '';
            }
        }
        


        function validateForm() {
            // Validate location name and image before submitting the form
            validatelockerid();
            validatelockername();
            validatelockersize(); 


            // Check if there are any validation errors
            var lockeridError = document.getElementById('lockeridError').innerHTML;
            var lockernameError = document.getElementById('lockernameError').innerHTML;
            var lockersizeError = document.getElementById('lockersizeError').innerHTML;

            if (lockeridError === '' && lockernameError === ''&& lockersizeError === '') {
                return true; // Submit the form
            } else {
                return false; // Stop form submission
            }
        }
    </script>
    


</body>
</html>