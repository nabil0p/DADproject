<?php
session_start();

// Check if user is logged in, redirect to login page if not
if (!isset($_SESSION["id"])) {
    header("Location: index.php");
    exit;
}
$page = 'item-assign-list.php'; 
$screen_name = 'Item Assign List';

include 'db/db_connection.php'; // Include your database connection

?>

<!DOCTYPE html>
<html>
<head>
    <!-- Head -->
    <?php include 'includecode/head.php' ?>
    <!-- Head -->
    
</head>
<style>
    <?php include 'includecode/plusdesign.php' ?>
    #alert-containers {
        display: none;  /* Hide the alert by default */
    }


</style>
    
<body id="page-top">

    <?php
        // Check if 'error' parameter is set in the URL
        if (isset($_GET['error'])) {
            // Display an error message with the value of the 'error' parameter
            echo '<div id="alert-containers" class="alert alert-danger" role="alert" style="display: block;">' . $_GET['error'] . '</div>';
            
        }

        // Check if 'error' parameter is set in the URL
        if (isset($_GET['success'])) {
            // Display an error message with the value of the 'error' parameter
            echo '<div id="alert-containers" class="alert alert-success" role="success" style="display: block;">' . $_GET['success'] . '</div>';
            
        }
    
    ?>

    <script>
        // Wait for the DOM to be ready
        document.addEventListener("DOMContentLoaded", function() {
            // Set a timeout to hide the error message after 5 seconds
            setTimeout(function() {
                var alertContainer = document.getElementById('alert-containers');
                if (alertContainer) {
                    // Hide the error message by setting display to 'none'
                    alertContainer.style.display = 'none';
                }
            }, 3000); // 5000 milliseconds = 5 seconds
        });
    </script>

    <script>
        function checkForm() {
            var checkboxes = document.getElementsByName('items[]');
            var isChecked = false;
            for (var i = 0; i < checkboxes.length; i++) {
                if (checkboxes[i].checked) {
                    isChecked = true;
                    break;
                }
            }
            if (!isChecked) {
                var alertContainer = document.getElementById('alert-containers');
                alertContainer.style.display = 'block';  // Show the alert
                alertContainer.innerHTML = 'Please check at least one checkbox.';
                
                // Hide the alert after 5 seconds (5000 milliseconds)
                setTimeout(function() {
                    alertContainer.style.display = 'none';
                }, 3000);

                return false;  // Prevent form submission
            }
            return true;  // Allow form submission
        }
    </script>

    <div id="alert-containers" class="alert alert-danger" role="alert"></div>

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Side Nav -->
        <?php include 'function/navigation/sidenav.php' ?>
        <!-- Side Nav -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include 'function/navigation/topnav.php' ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">Item Assign List</h1>
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Search</h6>
                        </div>
                        <form method="GET" id="myForm" action="item-assign-list.php" enctype="multipart/form-data">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                                <label for="itemMngtId">Item Management ID:</label><br/>
                                                <input type="text" class="form-control" id="itemMngtId" name="itemMngtId" value="<?php echo isset($_GET['itemMngtId']) ? $_GET['itemMngtId'] : ''; ?>">
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                                <label for="itemId">Item ID:</label><br/>
                                                <input type="text" class="form-control" id="itemId" name="itemId" value="<?php echo isset($_GET['locationid']) ? $_GET['locationid'] : ''; ?>">
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label for="size">Size:</label><br/>
                                            <select class="custom-select" id="size" name="size">
                                                <option value='' >Please Select</option>
                                                <option value="1" <?php echo (isset($_GET['size']) && $_GET['size'] === '1') ? 'selected' : ''; ?>>S</option>
                                                <option value="2" <?php echo (isset($_GET['size']) && $_GET['size'] === '2') ? 'selected' : ''; ?>>L</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-group">
                                            <label for="lockerlocation">Locker Location: </label>
                                            <select class="custom-select" id="lockerlocation" name="lockerlocation" >
                                                <option value=''>Please Select</option>
                                                <?php
                                                // Assuming $conn is your database connection
                                                $query = "SELECT locker_location_id, location_name , location_address FROM locker_location WHERE availability = 1;";
                                                $result = $conn->query($query);

                                                if ($result && $result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $location_id = $row['locker_location_id'];
                                                        $address = $row['location_name'];
                                                        echo "<option value='$location_id'";
                                                        echo (isset($_GET['lockerlocation']) && $_GET['lockerlocation'] === $location_id) ? 'selected' : '';
                                                        echo ">$address</option>";
                                                    }
                                                } else {
                                                    echo "<option value='' disabled>No locations available</option>";
                                                }

                                                // Close the result set
                                                $result->close();
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer py-3" >
                                <div class="row">
                                    <div class="col-xl-6 col-md-6">
                                        <div><button type="submit" onclick="resetForm()" class="btn btn-primary btn-sm" name="carian" value="carian" id="carian">Reset</button></div>
                                    </div>
                                    <script type="text/javascript">
                                        function resetForm() {
                                            document.forms["myForm"]["itemMngtId"].value = '';
                                            document.forms["myForm"]["itemId"].value = '';
                                            document.forms["myForm"]["lockerlocation"].value = '';
                                            document.forms["myForm"]["size"].value = '';
                                        }
                                    </script>
                                    <div class="col-xl-6 col-md-6">
                                        <div style="float:right;"><button type="submit" class="btn btn-primary btn-sm" name="carian" value="carian" id="carian"><i class="fa fa-search"></i>&nbsp;&nbsp;Search</button></div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        
                    <form method="post" action="item-assign-staff.php" onsubmit="return checkForm();">
                        <div class="card-header py-3">
                            <div class="row">
                                <div class="col-xl-6 col-md-6">
                                    <h6 class="m-0 font-weight-bold text-primary">Item Waiting List</h6>
                                </div>
                                <div class="col-xl-6 col-md-6">
                                    <div style="float:right;"><button type="submit" class="btn btn-primary btn-sm" ><i class="fa fa-box"></i>&nbsp;&nbsp;Assign to Staff</button></div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <?Php
                                        $sql = "SELECT 
                                                    im.item_mngt_id,
                                                    im.qrcode_delivery_id,
                                                    im.register_date,
                                                    i.item_id,
                                                    i.item_from, 
                                                    i.locker_location_id AS item_location, 
                                                    qr1.recipient_id,
                                                    ll.location_name, 
                                                    i.item_size_id
                                                FROM 
                                                    item_management im
                                                LEFT JOIN 
                                                    item i ON im.item_id = i.item_id
                                                LEFT JOIN 
                                                    locker_location ll ON i.locker_location_id = ll.locker_location_id
                                                LEFT JOIN 
                                                    qrcode_recipient qr1 ON im.qrcode_recipient_id = qr1.qrcode_recipient_id
                                                WHERE 
                                                    im.item_mngt_status_id = 4 
                                                "; 
                                    
                                    //filtering listing
                                    if (isset($_GET['carian'])) {
                                        $itemMngtId=$_GET['itemMngtId'];
                                        $itemId=$_GET['itemId'];
                                        $lockerlocation=$_GET['lockerlocation'];
                                        $size=$_GET['size'];
                                    
                                        if($itemId!=""){
                                            $sql= $sql . " and i.item_id LIKE '%$itemId%'";
                                        } 
                                        if($lockerlocation!=""){
                                            $sql= $sql . " and i.locker_location_id LIKE '%$lockerlocation%'";
                                        }
                                        if($size!=""){
                                            $sql= $sql . " and i.item_size_id LIKE '%$size%'";
                                        }
                                        if($itemMngtId!=""){
                                            $sql= $sql . " and im.item_mngt_id LIKE '%$itemMngtId%'";
                                        }
                                    
                                        $sql= $sql . " ORDER BY i.item_id asc";          
                                        
                                        $result = mysqli_query($conn, $sql);
                                        
                                        // Now that $result is defined, you can use mysqli_num_rows
                                        $rec_count = mysqli_num_rows($result);
                                    

                                        }else{
                                            //set semula tanpa filtering
                                            $sql = "SELECT 
                                                        im.item_mngt_id,
                                                        im.qrcode_delivery_id,
                                                        im.register_date,
                                                        i.item_id, 
                                                        i.item_from, 
                                                        i.locker_location_id AS item_location, 
                                                        qr1.recipient_id,
                                                        ll.location_name, 
                                                        i.item_size_id
                                                    FROM 
                                                        item_management im
                                                    LEFT JOIN 
                                                        item i ON im.item_id = i.item_id
                                                    LEFT JOIN 
                                                        locker_location ll ON i.locker_location_id = ll.locker_location_id
                                                    LEFT JOIN 
                                                        qrcode_recipient qr1 ON im.qrcode_recipient_id = qr1.qrcode_recipient_id
                                                    WHERE 
                                                        im.item_mngt_status_id = 4 
                                                    ORDER BY 
                                                        i.item_id asc;"; 

                                            $result = mysqli_query($conn, $sql);
                                            //print $sql;
                                        }

                                
                                    ?>
                                        <thead>
                                            <tr>
                                                <th style="width:50px;">Num.</th>
                                                <th style="width:80px;">&nbsp;&nbsp;<input type="checkbox" id="selectAllTop" name="selectAllTop" onclick="checkAll(this)" />&nbsp;&nbsp;All</th>
                                                <th>Item Management Id</th>
                                                <th>Item Id</th>
                                                <th>Recipient Id</th>
                                                <th>Item From</th>
                                                <th>Location Name</th>
                                                <th>Item Size</th>
                                                <th>Register Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $x = 1;
                                                while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                                                    $item_mngt_id = $row['item_mngt_id'];
                                                    $qrcode_delivery_id = $row['qrcode_delivery_id'];
                                                    $item_id = $row['item_id'];
                                                    $item_from = $row['item_from'];
                                                    $location_name = $row['location_name'];
                                                    $item_size_id = $row['item_size_id'];
                                                    $recipient_id = $row['recipient_id'];
                                                    $register_date = $row['register_date'];

                                                    if ($item_size_id === "1") {
                                                        $item_size_id = "Small";
                                                    }

                                                    if ($item_size_id === "2") {
                                                        $item_size_id = "Large";
                                                    }
                                            ?>
                                                <tr>
                                                    <td style="text-align: center;"><?php echo $x; ?></td>
                                                    <td style="width:80px; text-align:center;">
                                                        <input type="checkbox" id="checkbox_<?php echo $item_mngt_id; ?>" name="items[]" value="<?php echo $item_mngt_id; ?>" onclick="checkSelectAll()" />
                                                    </td>
                                                    <td><?php echo $item_mngt_id; ?></td>
                                                    <td><?php echo $item_id; ?></td>
                                                    <td><?php echo $recipient_id; ?></td>
                                                    <td><?php echo $item_from; ?></td>
                                                    <td><?php echo $location_name; ?></td>
                                                    <td><?php echo $item_size_id; ?></td>
                                                    <td><?php echo $register_date; ?></td>
                                                </tr>
                                            <?php $x++;
                                                } ?>
                                        </tbody>
                                </table>
                            </div>
                        </div>
                        </form>
                    </div>

                    </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include 'includecode/copyright.php'?>
            <!-- End of Footer -->
            
        </div>
        <!-- End of Content Wrapper -->

        

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>


    <!-- Foot -->
    <?php include 'includecode/foot.php' ?>
    <!-- Foot -->

    <script>
        function checkAll(allItem) {
            var checkboxes = document.querySelectorAll('input[name="items[]"]');
            for (var i = 0; i < checkboxes.length; i++) {
                checkboxes[i].checked = allItem.checked;
            }
        }

        function checkSelectAll() {
            var allTopCheckbox = document.getElementById("selectAllTop");
            var allBottomCheckbox = document.getElementById("selectAllBottom");
            var checkboxes = document.querySelectorAll('input[name="items[]"]');

            for (var i = 0; i < checkboxes.length; i++) {
                if (!checkboxes[i].checked) {
                    allTopCheckbox.checked = false;
                    allBottomCheckbox.checked = false;
                    return;
                }
            }
            allTopCheckbox.checked = true;
            allBottomCheckbox.checked = true;
        }
    </script>


</body>
</html>