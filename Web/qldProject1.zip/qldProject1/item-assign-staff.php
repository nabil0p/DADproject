<?php
session_start();

// Check if user is logged in, redirect to login page if not
if (!isset($_SESSION["id"])) {
    header("Location: login.php");
    exit;
}
$page = 'item-assign-staff.php'; 
$screen_name = 'Assign Items to Staff';

include 'db/db_connection.php'; // Include your database connection


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $items = $_POST["items"];
    $qrcode = isset($_POST["qrcode"]) ? $_POST["qrcode"] : array();
    $processedItems = array();
    $processedQrcode = array();

    foreach($items as $itemMngt_id) {
        // Process each item_id here
        // For example, let's say you're just storing them in the new array
        $processedItems[] = $itemMngt_id;  // No need to convert to int if $item_id is a string
    }

    foreach($qrcode as $qrcodeid) {
        // Process each item_id here
        // For example, let's say you're just storing them in the new array
        $processedQrcode[] = $qrcodeid;  // No need to convert to int if $item_id is a string
    }

    // Create a string of comma-separated IDs
    $idStr = implode(',', $processedItems);
    echo $idQrcode = implode(',', $processedQrcode);
}


?>

<!DOCTYPE html>
<html>
<head>
    <!-- Head -->
    <?php include 'includecode/head.php' ?>
    <!-- Head -->
</head>
<style>
    <?php include 'includecode/plusdesign.php' ?>
</style>

    
<body id="page-top">
    <?php
    // Check if 'error' parameter is set in the URL
    if (isset($_GET['error'])) {
        // Display an error message with the value of the 'error' parameter
        echo '<div id="alert-containers" class="alert alert-danger" role="alert">' . $_GET['error'] . '</div>';
        
    }

    // Check if 'error' parameter is set in the URL
    if (isset($_GET['success'])) {
        // Display an error message with the value of the 'error' parameter
        echo '<div id="alert-containers" class="alert alert-success" role="success">' . $_GET['success'] . '</div>';
        
    }
    
    ?>

    <script>
        // Wait for the DOM to be ready
        document.addEventListener("DOMContentLoaded", function() {
            // Set a timeout to hide the error message after 5 seconds
            setTimeout(function() {
                var alertContainer = document.getElementById('alert-containers');
                if (alertContainer) {
                    // Hide the error message by setting display to 'none'
                    alertContainer.style.display = 'none';
                }
            }, 3000); // 3000 milliseconds = 3 seconds
        });
    </script>
    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Side Nav -->
        <?php include 'function/navigation/sidenav.php' ?>
        <!-- Side Nav -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include 'function/navigation/topnav.php' ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">Assign Item to Staff</h1>
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Assign Item to Staff</h6>
                        </div>
                        <form method="post" action="function/update-assign-staff.php" enctype="multipart/form-data" onsubmit="return validateForm()">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group">
                                                <label for="itemMngtId">Item Management Id:</label>
                                                <input type="text" class="form-control" id="itemMngtId" name="itemMngtId" value="<?php echo $idStr; ?>" readonly onkeyup="validateItemMngtId()">
                                                <span id="itemMngtIdError" class="errorss"></span>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group">
                                                <label class="required" for="courierid">Staff (Courier Delivery):</label>
                                                <select class="custom-select" id="courierid" name="courierid" onchange="validateCourierId(); updateUsername()">
                                                    <option value="">Please Select</option>
                                                    <?php
                                                        // Assuming you have a database connection established already
                                                        $sql1 = "SELECT 
                                                                    users.qld_id, 
                                                                    users.username, 
                                                                    courier_details.availability_id AS available
                                                                FROM 
                                                                    users 
                                                                LEFT JOIN 
                                                                    courier_details ON users.qld_id = courier_details.courier_id
                                                                WHERE 
                                                                    users.role_id = 2 AND courier_details.availability_id = '1' 
                                                                ORDER BY 
                                                                    users.qld_id ASC;";

                                                        $result1 = mysqli_query($conn, $sql1);
                                                        while($row = mysqli_fetch_assoc($result1)) {
                                                            $courier_id = $row['qld_id'];
                                                            $username = $row['username'];
                                                            echo "<option value='" . $courier_id . "' data-username='" . $username . "'>" . $username . "</option>";
                                                        }
                                                    ?>
                                                </select>
                                                <span id="courieridError" class="errorss"></span>
                                                <input type="hidden" id="username" name="username" value="">
                                                <script>
                                                function updateUsername() {
                                                    var select = document.getElementById("courierid");
                                                    var selectedOption = select.options[select.selectedIndex];
                                                    var username = selectedOption.getAttribute("data-username");
                                                    document.getElementById("username").value = username;
                                                }
                                                </script>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer py-3">
                                    <div class="row">
                                        <div class="col-xl-6 col-md-6">
                                            <div class="small text-white">
                                                <a href="item-assign-list.php?" class="btn btn-primary btn-sm"><i class="fa fa-list"></i>&nbsp;&nbsp;View Assignment List</a>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-md-6">
                                            <div style="float:right;">
                                                <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i>&nbsp;&nbsp;Assign</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include 'includecode/copyright.php'?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Foot -->
    <?php include 'includecode/foot.php' ?>
    <!-- Foot -->

    <script>
        function validateItemMngtId() {
            var itemMngtId = document.getElementById('itemMngtId').value;
            var itemMngtIdError = document.getElementById('itemMngtIdError');

            if (itemMngtId.trim() === '') {
                itemMngtIdError.innerHTML = 'Customer Id is required';
            } else {
                itemMngtIdError.innerHTML = '';
            }
        }
        function validateCourierId() {
            var courierid = document.getElementById('courierid').value; // Corrected ID
            var courieridError = document.getElementById('courieridError'); // Corrected ID

            if (courierid.trim() === '') {
                courieridError.innerHTML = 'Courier Id is required';
            } else {
                courieridError.innerHTML = '';
            }
        }


        function validateForm() {
            // Call all individual validation functions
            validateItemMngtId();
            validateCourierId(); // Corrected function name

            // Check if there are any validation errors
            var itemMngtIdError = document.getElementById('itemMngtIdError').innerHTML;
            var courieridError = document.getElementById('courieridError').innerHTML; // Corrected variable name

            if (itemMngtIdError === '' && courieridError === '') {
                return true; // Submit the form
            } else {
                return false; // Stop form submission
            }
        }
    </script>



</body>
</html>