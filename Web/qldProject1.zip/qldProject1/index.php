<?php
    session_start();

    // Check if user is logged in, redirect to login page if not
    if (!isset($_SESSION["id"])) {
        header("Location: login.php");
        exit;
    }

    $page = 'index.php'; 
    $screen_name = 'Dashboard';
    $userid = $_SESSION["id"];
    $roleid = isset($_SESSION["role_id"]) ? $_SESSION["role_id"] : ''; 

    include 'db/db_connection.php'; // Include your database connection

    // Function to execute query and fetch result
    function executeQuery($conn, $sql) {
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
        return $row;
    }

    // SQL query to get waiting count and IDs
    $sql_waiting = "SELECT 
                        COUNT(*) AS item_waiting
                        FROM 
                        item_management
                        WHERE 
                        item_mngt_status_id = 4";

    $result = $conn->query($sql_waiting);

    if ($result && $result->num_rows > 0) {
        $row_waiting = $result->fetch_assoc();
        $item_waiting = $row_waiting["item_waiting"];
    } else {
        $item_waiting = 0; // Default value in case of no result
    }

    // SQL query to get item management count and IDs
    $sql_item_management = "SELECT 
                                COUNT(*) AS Item_Management_Count,
                                GROUP_CONCAT(item_mngt_id) AS Item_Management_IDs
                            FROM 
                                item_management";
    $row_item_management = executeQuery($conn, $sql_item_management);
    $item_management_count = $row_item_management["Item_Management_Count"];
    $item_management_ids = $row_item_management["Item_Management_IDs"];

    // SQL query to get the count of items with status 'done' (status ID 3)
    $sql_done = "SELECT 
                COUNT(*) AS Item_Done_Count
                FROM 
                item_management
                WHERE 
                item_mngt_status_id = 3";

    $resultDone = $conn->query($sql_done);

    if ($resultDone && $resultDone->num_rows > 0) {
        $row_item_done = $resultDone->fetch_assoc();
        $Item_Done_Count = $row_item_done["Item_Done_Count"];
    } else {
        $Item_Done_Count = 0; // Default value in case of no result
    }


    
    $pic_id = $userid; // Replace "your_pic_id_here" with the actual pic_id you want to query

    // SQL query to get registered count for a particular PIC
    $sql_registered_count = "SELECT 
                                COUNT(item_mngt_id) AS registered_count 
                            FROM 
                                item_management 
                            WHERE 
                                pic_id = '$pic_id'";
    $row_registered_count = executeQuery($conn, $sql_registered_count);
    $registered_count = $row_registered_count['registered_count'];

    // SQL query to get item count for items with status ID 1
    $sql_item_count = "SELECT COUNT(*) AS Item_Count
                        FROM item_management
                        WHERE item_mngt_status_id = 1";
    $result_item_count = mysqli_query($conn, $sql_item_count);

    // Fetch the row
    $row_item_count = mysqli_fetch_array($result_item_count, MYSQLI_ASSOC);
    $item_count = $row_item_count['Item_Count'];

?>

<!DOCTYPE html>
<html>
<head>
    <!-- Head -->
    <?php include 'includecode/head.php' ?>
    <!-- Head -->
</head>
<style>
    <?php include 'includecode/plusdesign.php' ?>
</style>
    
<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Side Nav -->
        <?php include 'function/navigation/sidenav.php' ?>
        <!-- Side Nav -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include 'function/navigation/topnav.php' ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">Dashboard</h1>
                     <!-- Content Row -->
                     <div class="row">
                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Total Waiting Item </div>
                                            <div class="h4 mb-0 font-weight-bold text-gray-800"><?php echo $item_waiting; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clock fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Item Management Count</div>
                                            <div class="h4 mb-0 font-weight-bold text-gray-800"><?php echo $item_management_count; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-box fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Item Picked
                                            </div>
                                            <div class="h4 mb-0 font-weight-bold text-gray-800"><?php echo $Item_Done_Count; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                            
                             <!-- Earnings (Monthly) Card Example -->
                            <div class="col-xl-3 col-md-6 mb-4">
                                <div class="card border-left-warning shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">My Total Item Register
                                                </div>
                                                <div class="h4 mb-0 font-weight-bold text-gray-800"><?php echo $registered_count; ?></div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <div class="row">
                                <div class="col-xl-6 col-md-6">
                                    <div style="float:left;margin-top:5px;"><h5 class="m-0 font-weight-bold text-primary">Item To Be Deliver (Total: <?php echo $item_count;?>)</h5></div>
                                </div>
                                <div class="col-xl-6 col-md-6">
                                    <div style="float:right;"><a href="item-register.php" class="btn btn-primary btn-sm" style="margin-top:3px;"><i class="fa fa-clipboard-list"></i>&nbsp;&nbsp;Add Item</a></div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <?Php

                                   $sql_select_items = "SELECT 
                                                            im.item_mngt_id, 
                                                            im.register_date, 
                                                            qd.courier_id,
                                                            im.register_date,
                                                            ims.status_name
                                                        FROM 
                                                            item_management im
                                                        INNER JOIN 
                                                            item_management_status ims ON im.item_mngt_status_id = ims.item_mngt_status_id
                                                        INNER JOIN 
                                                            qrcode_delivery qd ON qd.qrcode_delivery_id = im.qrcode_delivery_id
                                                        WHERE 
                                                            ims.status_name = 'Pending';";
                                    // Replace 'start_date' with your desired start date
                                    $result_select_items = $conn->query($sql_select_items);
                                    //print $sql;

                                    ?>
                                    <thead>
                                        <tr>
                                            <th width="25px">Num.</th>
                                            <th>Resit ID</th>
                                            <th>Register Date</th>
                                            <th>Courier Id</th>
                                            <th>Due Count (Day)</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th width="25px">Num.</th>
                                            <th>Resit ID</th>
                                            <th>Register Date</th>
                                            <th>Courier Id</th>
                                            <th>Due Count (Day)</th>
                                            <th>Status</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php $x=1;
                                            while ($row=mysqli_fetch_array($result_select_items,MYSQLI_ASSOC)){

                                                $item_mngt_id = $row['item_mngt_id'];
                                                $reg_date = $row['register_date'];
                                                $courier_id = $row['courier_id'];
                                                $status_name = $row['status_name'];
                                                    
                                                if ($status_name == 'Pending') {
                                                    $color = 'orange';    
                                                } 
                                                
                                                $current_date = date("Y-m-d");
                                                $register_date = date("Y-m-d", strtotime($reg_date));

                                                $current_date = new DateTime($current_date);
                                                $register_date = new DateTime($register_date);

                                                if ($current_date > $register_date) {
                                                    $interval = $current_date->diff($register_date);
                                                    $due_count = $interval->format('%a'); // Calculate difference in days
                                                } else {
                                                    $due_count = 0;
                                                }
                                            ?>
                                            <tr>
                                                <td style="vertical-align: middle;" ><?php echo $x;?></td>
                                                <td style="vertical-align: middle;"><?php echo $item_mngt_id; ?></td>
                                                <td style="vertical-align: middle;"><?php echo $reg_date; ?></td>
                                                <td style="vertical-align: middle;"><?php echo $courier_id; ?></td>
                                                <td style="vertical-align: middle;"><?php echo $due_count; ?></td>
                                                <td style="vertical-align: middle;">
                                                        <div class="btn btn-sm" style="background-color: <?php echo $color; ?>;color: white; margin-top: 3px; cursor: default; pointer-events: none; user-select: none;">
                                                            <?php echo $status_name; ?>
                                                        </div>
                                                    </td>
                                            </tr>
                                        <?php $x++;} ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include 'includecode/copyright.php'?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Foot -->
    <?php include 'includecode/foot.php' ?>
    <!-- Foot -->


</body>
</html>